# マルチテナントにおける新規テナント開発方法

バックエンドではconfig.pyを編集することによって新規APIの追加および、新規アプローチの追加を行う

## api_config_listの編集
1. 設定したapi名にたいしてキーワード生成行うか、検索を行うか、回答生成をおこなうか決定する
2. 動作させる場合、各動作に対してどの関数を使用するか決定する
3. api_config_listに以下の内容を追加する
    api_config_list = {
        "chat" : {
            "preprocess_instance" : False,
            "search_instance" : False,
            "create_llm_answer_instance" : GetGptAnswer()
        },
        ...
        "new_api" : {
            "preprocess_instance" : Instance or False
            "search_instance" : Instance or False
            "create_llm_answer_instance : Instance or False
        }
    }

## config_listの編集
1. 設定した利用方法名称はどのAPIで動作させるか決定する
2. 各動作に対して以下の項目の値を決定する
3. config_listに以下の内容を追加する
  config_list = {
     ...,
    "new_usecase" : {
        "search_client" : client Instance or None
        "search_index" : Index Name or None, 
        "sourcepage_field" : filed name or None,
        "content_field" : field name or None,
        "blob_url" : field name or None,
        "further_question_score" : score value or None,
        "search_engine" : engine name or None,
        "search_success_template" : template sentence or "",
        "search_failed_template" : template sentence or "",
        "fields": filed name list or None, 
        "gpt_deployment" : Azure openAI deployment name or None,
        "chatgpt_deployment" : Azure openAI deployment name or None, 
        "embedding_deployment" : Azure openAI embedding deployment name or None, 
        "retry_count" : count value or None,
        "retry_interval" : interval value or None,
        "chat_temperature" : value or None,
        "system_prompt" :  template sentence or "",
        "prompt_template" : template sentence or "",
        "output_max_token" : token value or None
    }
  }

### 設定するかどうかは以下を参照する
"search_client" : 検索実行時は設定 
"search_index" : 検索実行時は設定
"sourcepage_field" : 検索実行時は設定
"content_field" : 検索実行時は設定
"blob_url" : 検索実行時は設定
"further_question_score" : 検索実行時は設定
"search_engine" : 検索実行時は設定
"search_success_template" : 検索実行時は設定
"search_failed_template" : 検索実行時は設定
"fields": 検索実行時は設定
"gpt_deployment" : キーワード生成実行時は設定
"chatgpt_deployment" : 回答生成実行時は設定 
"embedding_deployment" : 検索実行時は設定 
"retry_count" : キーワード生成または回答生成実行時は設定
"retry_interval" : キーワード生成または回答生成実行時は設定
"chat_temperature" : キーワード生成または回答生成実行時は設定
"system_prompt" : 回答生成実行時は設定
"prompt_template" : 回答生成実行時は設定
"output_max_token" : 回答生成実行時は設定