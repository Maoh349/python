import json
import datetime
from azure.storage.blob import ContainerClient
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient, generate_blob_sas, BlobSasPermissions
import pandas as pd
from io import BytesIO
import io
from util.logger import create_debug_esg_azure_log_error

def UploadESGFile(blob_container: ContainerClient, df: pd.DataFrame, thread_key : str , output_filename : str, overrides: dict) -> str:

    blob_name = "esg/output/" + output_filename
    output = BytesIO()
    # CSVファイルに変換して保存
    df.to_csv(output, index=False, encoding="shift-jis")
    output.seek(0)

    log_params = {
        "blob_name" : blob_name,
        "thread_key" : thread_key
    }

    try:
        blob_client = blob_container.get_blob_client(blob_name)
        blob_client.upload_blob(output, overwrite=True)
    except Exception as e:
        create_debug_esg_azure_log_error("env", "upload", overrides, **log_params)
        raise


def GenerateESGUrl(blob_service_client : BlobServiceClient, container_name : str, output_filename: str, azure_web_url: str, overrides:dict, expiration_minutes=60)-> str:
    
    try:
        
        blob_name = "esg/output/" + output_filename
        log_params = {
            "blob_account_name" : blob_service_client.account_name,
            "container_name" : container_name,
            "blob_name" : blob_name 
        }
        url =  f"{azure_web_url}{container_name}/{blob_name}" 
        return url
    except Exception as e:
        create_debug_esg_azure_log_error("env", "generate_url", overrides, **log_params)
        raise

def UpdateTmpFile(blob_container : ContainerClient, overrides : dict, input_filename: str, output_filename : str, thread_key : str, total_num_of_scheduled_tasks:int,total_num_of_completed_tasks:int,status:str, created:str):

    blob_name = "esg/tmpfolder/"+ thread_key+"_"+"tmpfile.json"
    tmp_data = {
        "status" : status,
        "input_filename" : input_filename,
        "output_filename" : output_filename,
        "thread_key" : thread_key, 
        "total_num_of_scheduled_tasks" : total_num_of_scheduled_tasks,
        "total_num_of_completed_tasks" : total_num_of_completed_tasks,
        "user_name" : overrides.get("user_name"),
        "created" : created

    }
    tmp_data_str = json.dumps(tmp_data, ensure_ascii=False)

    log_params = {
        "status" : status,
        "blob_name"  : blob_name,
        "input_filename" : input_filename,
        "output_filename" : output_filename,
        "thread_key" : thread_key,
        "total_num_of_scheduled_tasks" : total_num_of_scheduled_tasks,
        "total_num_of_completed_tasks" : total_num_of_completed_tasks-1,
        "created":created
    }

    try:
        blob_client = blob_container.get_blob_client(blob_name)
        blob_client.upload_blob(tmp_data_str, overwrite=True)
    except Exception as e:
        create_debug_esg_azure_log_error("env", "update_tmpfile", overrides, **log_params)
        raise


def ChangeStatusTmpFile(blob_container : ContainerClient, overrides:dict, thread_key :str):
    blob_name = "esg/tmpfolder/" +thread_key +"_"+"tmpfile.json"
    log_params = {
        "blob_name" : blob_name,
        "thread_key" : thread_key
    }
    try:
        blob_client = blob_container.get_blob_client(blob_name)
        blob_data = blob_client.download_blob().readall()
        data = json.loads(blob_data.decode('utf-8'))
        print(data)
        data["status"] = "cancel"
        tmp_data_str = json.dumps(data, ensure_ascii=False)
        blob_client.upload_blob(tmp_data_str, overwrite=True)
    except Exception as e:
        create_debug_esg_azure_log_error("env", "change_status_tmpfile", overrides, **log_params)
        raise
        

def GetTmpFileInfo(blob_container : ContainerClient, container_name : str, azure_web_url : str, overrides : dict):
    thread_key_list = []
    try:
        # tmpfolder配下のtmpfile.jsonの一覧を取得
        blob_list = blob_container.list_blobs("esg/tmpfolder")

        # pathになっているのでファイル名のみを取得
        lis = []
        for blob in blob_list:
            lis.append(blob.name.split("/")[-1])
        # 各一時ファイルの状況を取得しdictに追加
    
        for filename in lis:
            thread_key = filename.split("_")[0]
            blob_name = "esg/tmpfolder/" + filename
            blob_client = blob_container.get_blob_client(blob_name)
            blob_data = blob_client.download_blob().readall()
            data = json.loads(blob_data.decode('utf-8'))
            output_filename = data["output_filename"]
            status = data["status"]
            url = ""
            if status == "completion" or status == "partialcompletion" or status == "cancel" or status == "error":
                url = GenerateESGUrl(blob_client, container_name, output_filename, azure_web_url , overrides)
            data["url"] = url
            thread_key_list.append(data)
        
        sorted_data = sorted(thread_key_list, key=lambda x: x["created"],reverse=True )

        return sorted_data


    except Exception as e:
        create_debug_esg_azure_log_error("env", "get_tmpfileinfo", overrides)
        raise

def DeleteTmpFile(blob_container : ContainerClient, thread_key : str, overrides :dict):
    blob_name = "esg/tmpfolder/"+ thread_key+"_"+"tmpfile.json"
    log_params = {
        "blob_name" : blob_name,
        "thread_key" : thread_key
    }
    try:
        blob_client = blob_container.get_blob_client(blob_name)
        if blob_client:
            blob_client.delete_blob()
    except Exception as e:
        create_debug_esg_azure_log_error("env", "delete_tmpfile", overrides, **log_params)
        raise  

def Deleteoutput(blob_container : ContainerClient, output_filename:str, overrides : dict):
    blob_name = "esg/output/"+output_filename
    log_params = {
        "blob_name" : blob_name,
        "output_filename" : output_filename 
    }
    try:
        blob_client = blob_container.get_blob_client(blob_name)
        if blob_client:
            blob_client.delete_blob()
    except Exception as e:
        create_debug_esg_azure_log_error("env", "delete_output", overrides, **log_params)
        raise 
    
def CheckStatusTmpFile(blob_container:ContainerClient, overrides :dict, thread_key :str):
    blob_name = "esg/tmpfolder/" +thread_key +"_"+"tmpfile.json"
    log_params = {
        "blob_name" : blob_name,
        "thread_key" : thread_key
    }
    try:
        blob_client = blob_container.get_blob_client(blob_name)
        blob_data = blob_client.download_blob().readall()
        data = json.loads(blob_data.decode('utf-8'))
        return data["status"]
    except Exception as e:
        create_debug_esg_azure_log_error("env", "create_process_tmpfile", overrides, **log_params)
        raise

def CountProcessingTmpfile(blob_container:ContainerClient, overrides:dict):
    try:
        # tmpfolder配下のtmpfile.jsonの一覧を取得
        blob_list = blob_container.list_blobs("esg/tmpfolder")

        # pathになっているのでファイル名のみを取得
        lis = []
        for blob in blob_list:
            lis.append(blob.name.split("/")[-1])
        # 各一時ファイルの状況を取得しdictに追加
        processing_status_count = 0
        for filename in lis:
            thread_key = filename.split("_")[0]
            blob_name = "esg/tmpfolder/" + filename
            blob_client = blob_container.get_blob_client(blob_name)
            blob_data = blob_client.download_blob().readall()
            data = json.loads(blob_data.decode('utf-8'))
            status = data["status"]
            if status == "processing":
                processing_status_count += 1
        return processing_status_count
    except Exception as e:
        create_debug_esg_azure_log_error("env", "count_porcessing_tmpfile", overrides)
        raise

def GetMasterdata(blob_container:ContainerClient, overrides:dict):
    blob_name = "esg/masterdata/masterdata.json"
    log_params = {
        "blob_name" : blob_name,
    }
    try:
        blob_client = blob_container.get_blob_client(blob_name)
        blob_data = blob_client.download_blob().readall()
        data = json.loads(blob_data.decode('utf-8'))
        return data
    except Exception as e:
        create_debug_esg_azure_log_error("env", "get_masterdata", overrides, **log_params)
        raise

def GetLatestInitializationTmpfile(blob_container : ContainerClient, overrides:dict):
    try:
        # tmpfolder配下のtmpfile.jsonの一覧を取得
        blob_list = blob_container.list_blobs("esg/tmpfolder")

        # pathになっているのでファイル名のみを取得
        lis = []
        for blob in blob_list:
            lis.append(blob.name.split("/")[-1])
        # 各一時ファイルの状況を取得しdictに追加
        initialization_tmpfile_list = []
        for filename in lis:
            blob_name = "esg/tmpfolder/" + filename
            blob_client = blob_container.get_blob_client(blob_name)
            blob_data = blob_client.download_blob().readall()
            data = json.loads(blob_data.decode('utf-8'))
            status = data["status"]
            if status == "initialization":
                initialization_tmpfile_list.append((data["created"], data["thread_key"]))
        initialization_tmpfile_list.sort()
        latest_thread_key = initialization_tmpfile_list[0][1]
        return latest_thread_key
    except Exception as e:
        create_debug_esg_azure_log_error("env", "get_latest_initialization_tmpfile", overrides)
        raise