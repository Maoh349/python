import time
from util.text import nonewlines, stringnewlines
from util.logger import create_debug_querylog_error
from util.text import nonewlines
from openai import AzureOpenAI

# ***加藤追記 定義ファイルでインスタンス化して渡したいのでクラス化
class GetRelevantDocumentsES():

    def handle_search_client_error(self,instance, startTime:str, dt:str, tenant:str, approach:str, env:str, latestQuery:str, q:str, overrides:dict, step1elapsedTime:float):
        """
        エラーログを出力します。
        """
        step2elapsedTime=time.time() - startTime
        params = {
            "answer": "step2 Elasticsearch apiで例外発生",
            "q":q.replace('\n', '<br>'),
            "search_engine": instance.search_engine,
            "step1elapsedTime":step1elapsedTime,
            "step2elapsedTime":step2elapsedTime
        }
        create_debug_querylog_error(dt, env, latestQuery, overrides, approach, tenant, **params)

    #　***加藤追記　関数の名前変更しました
    def get_relevant_documents(self,instance, top, overrides: dict, q: str, fulltext_search_query_body, get_vector_squery_body, tenant:str, approach: str, env: str, latestQuery:str, dt, startTime, step1elapsedTime:float, openai_client: AzureOpenAI) -> list: 
        """
        検索用のキーワードから、関連する文書を取得します。
        """
        
        try:
            # 埋め込みベクトルの取得
            vector_response = openai_client.embeddings.create(
                input = latestQuery,
                model = instance.embedding_deployment
            )
            vector =  vector_response.data[0].embedding
            
            fulltext_search_response = self.fulltext_search_results(instance.search_client, instance.search_index, fulltext_search_query_body)
            text_result = fulltext_search_response["hits"]["hits"]
            
            vector_search_query_body = get_vector_squery_body(vector)
            vector_search_response = self.vector_search_results(instance.search_client, instance.search_index, vector_search_query_body)
            vector_result = vector_search_response["hits"]["hits"]
            
            combined_list = text_result + vector_result
            # 重複を削除
            result_list = []
            for item in combined_list:
                flag=False
                for record in result_list:        
                    if item["_id"] == record["_id"]:
                        flag=True
                if flag != True :        
                    result_list.append(item)

            for item in result_list:
                score = self.rerank(item["_id"], text_result, vector_result)
                item["score"] = score
            
            sorted_json_array = sorted(result_list, key=lambda x: x["score"], reverse=True)
            r= sorted_json_array[0:top]

        except Exception as e:
            self.handle_search_client_error(instance, startTime, dt, tenant, approach, env, latestQuery, q, overrides, step1elapsedTime)
            raise
        
        relevant_documents = []
        for i, doc in enumerate(r):
            item = doc["_source"]
            result_str = f"{i+1}. @@@文書名:{nonewlines(item[instance.sourcepage_field])} @@@参考リンク: {item[instance.blob_url]} @@@本文: {stringnewlines(item[instance.content_field])}\n\n\n"
            relevant_documents.append(result_str)

        score = 0
        if len(text_result) >= 3:
            score = text_result[2]["_score"] 
        elif len(text_result) > 0:
            score = text_result[-1]["_score"] 
        
        return relevant_documents, score 

    def fulltext_search_results(self, client, index, fulltext_search_query_body):
        """
        Elasticsearchに対して全文検索
        """
        retry_count=1000
        for count in range( retry_count ):
            try:
                result = client.search(index=index, body=fulltext_search_query_body, ignore=400)
            except Exception as e:     
                print('retrying...', e)      
                time.sleep(1)        
                if count + 1 >=retry_count :
                    raise e    
            else:
                break

        return result

    #Elasticsearchに対してベクトル検索
    def vector_search_results(self, client, index, vector_search_query_body):
        retry_count=1000
        for count in range( retry_count ):
            try:
                result = client.search(index=index, body=vector_search_query_body, ignore=400)
            except Exception as e:     
                print('retrying...', e)      
                time.sleep(1)        
                if count + 1 >=retry_count :
                    raise e    
            else:
                break

        return result

    def rerank(self, doc, text_result , vector_result):
        """
        全文検索、ベクトル検索の結果の各チャンクの順位を元に総合スコアを算出
        """
        k=20
        score = 0.0
        for index, item in enumerate(text_result):
            if item.get("_id") == doc:
                score += 1.0 / ( k + (index+1) )

        for index, item in enumerate(vector_result):
            if item.get("_id") == doc:
                score += 1.0 / ( k + (index+1) )
        return score