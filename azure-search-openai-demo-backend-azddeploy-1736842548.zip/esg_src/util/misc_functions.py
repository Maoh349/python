    
def create_source_columns(top : int, reference_columns : list) -> list:
    source_columns = []
    for column_name in reference_columns:
        for i in range(top):
            _column_name = f"{column_name}_{i}"
            source_columns.append(_column_name)
    return source_columns

def create_report_filter_list(report_reference : list, reporttype_list : list) -> list:
    report_reference_list = report_reference.split("、")
    report_filter_list = []
    for reporttype in reporttype_list:
            for report_reference_ in report_reference_list:
                if reporttype in report_reference_:
                    report_filter_list.append(reporttype)
    if len(report_filter_list) == 0:
            report_filter_list = reporttype_list
    return report_filter_list


def create_source_list(relevant_documents : list, AUZRE_WEB_URL:str):
    source_name_list = []
    source_url_list = []
    source_text_list = []
    for i in relevant_documents:
            f = i.split("@@@")
            source_name = f[1][4:]
            source_name = source_name.split("sourcedata_")[1]
            source_url = f[2][6:]
            download_url = AUZRE_WEB_URL+"content/"+source_url[1:]
            #source_text = f[3][3:]
            source_name_list.append(source_name)
            source_url_list.append(download_url)
            #source_text_list.append(source_text)
    source_list = source_name_list+source_url_list#+source_text_list
    return source_list