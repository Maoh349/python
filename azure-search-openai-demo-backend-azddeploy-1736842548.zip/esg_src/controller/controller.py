import os
import pandas as pd
import datetime
import time
from elasticsearch import Elasticsearch
from esg_src.approaches.readprepretrivellmtwice import ReadPrepRetrieveLLMTwice
from esg_src.util.azureutils import UploadESGFile, GenerateESGUrl,  UpdateTmpFile, CheckStatusTmpFile, CountProcessingTmpfile, GetMasterdata, GetLatestInitializationTmpfile
from azure.identity import DefaultAzureCredential
from azure.core.exceptions import ResourceExistsError
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient, generate_blob_sas, BlobSasPermissions
from util.logger import  create_debug_querylog_info
import threading
from openai import AzureOpenAI
AZURE_OPENAI_API_VERSION = os.environ.get("AZURE_OPENAI_API_VERSION") or "2024-02-01"
AZURE_OPENAI_SERVICE = os.environ.get("AZURE_OPENAI_SERVICE") or "myopenai_us"

azure_credential = DefaultAzureCredential()
# openaikeyの設定
openai_token = azure_credential.get_token("https://cognitiveservices.azure.com/.default")
api_key = openai_token.token

openai_4o_client = AzureOpenAI(
    api_key=api_key,  
    api_version=AZURE_OPENAI_API_VERSION,
    base_url=f"https://{AZURE_OPENAI_SERVICE}.openai.azure.com/openai/",
)

class ESGController():
    def __init__(self, search_client : Elasticsearch, search_index : str, storage: str, sourcepage_field :str, blob_url : str, content_field: str,  further_question_score: int, search_engine : str, fields:list , chatgpt_deployment : str, embedding_deployment: str, retry_count : int, retry_interval : int, chat_temperature : int, system_prompt : str, prompt_template : list[str], output_max_token : int , max_thread_num :int,thread_sleep_time:int, blob_container, approx_max_tokens: int, token_threshold: int):
        self.search_client = search_client
        self.search_index = search_index
        self.storage = storage
        self.sourcepage_field = sourcepage_field
        self.blob_url = blob_url
        self.content_field = content_field
        self.further_question_score = further_question_score
        self.search_engine = search_engine
        self.fields = fields
        self.chatgpt_deployment = chatgpt_deployment
        self.embedding_deployment = embedding_deployment
        self.retry_count = retry_count
        self.retry_interval = retry_interval
        self.chat_temperature = chat_temperature
        self.system_prompt = system_prompt
        self.prompt_template = prompt_template
        self.output_max_token = output_max_token
        self.blob_container = blob_container
        self.max_thread_num = max_thread_num
        self.thread_sleep_time = thread_sleep_time
        self.approx_max_tokens = approx_max_tokens
        self.token_threshold = token_threshold

    def Controller(self,overrides:dict, input_filename : str, output_filename : str,  df :pd.DataFrame, thread_key : str,total_num_of_scheduled_tasks:int,  tenant : str , env : str, approach : str, created:str, AZURE_WEB_URL:str, openai_client:AzureOpenAI) :
        
        output_rows = []
        impl = ReadPrepRetrieveLLMTwice(instance = self)
        total_num_of_completed_tasks = 0
        #blobの更新に多少誤差あるので少し待機
        time.sleep(1)
        # tmpfileからprocessingの数を取得
        processing_status_count = CountProcessingTmpfile(self.blob_container,overrides)
        # 待機中のファイルで処理開始時間が古いthread_keyを取得
        latest_thread_key = GetLatestInitializationTmpfile(self.blob_container, overrides)
        # 2スレッド以上は同時実行させない かつ　待機中のファイルで処理開始時間が最も早いものだけループから抜けさせる
        while True :
            if processing_status_count < self.max_thread_num:
                latest_thread_key = GetLatestInitializationTmpfile(self.blob_container,overrides)
                if thread_key == latest_thread_key:
                    break
            time.sleep(self.thread_sleep_time)
            # 待機してスレッド数の更新
            processing_status_count = CountProcessingTmpfile(self.blob_container,overrides)
            # ファイル名の更新
            latest_thread_key = GetLatestInitializationTmpfile(self.blob_container,overrides)
            ## 一時ファイルのstatus確認して、cancelなら処理中断
            status = CheckStatusTmpFile(self.blob_container, overrides, thread_key)

            if status == "cancel":
                return 
        
        # マスターデータの取得
        masterdata = GetMasterdata(self.blob_container, overrides)

        # 実行中に処理エラーが起きたらstatusをpartialcompletionに
        try:
            ## 列ごとにAI回答作成
            for i, row in enumerate(df.itertuples()): 
                self.ensure_openai_token()
                # 中断されたらスレッド停止します
                # readprepretrivellmtwiceに仕込めばもう少し高頻度で中断のシグナル送ること可能だが、現状でも１０秒程度で実行停止できるのでこれで十分かと
                status = CheckStatusTmpFile(self.blob_container, overrides, thread_key)
                if status == "cancel":
                    return
                #一時ファイルの作成/更新を行います
                startTime = time.time()
                total_num_of_completed_tasks = i
                UpdateTmpFile(self.blob_container, overrides, input_filename, output_filename, thread_key,  total_num_of_scheduled_tasks, total_num_of_completed_tasks, "processing", created)
                data = {
                    "security_code" : row[1],
                    "key_issue" : row[2],
                    "evaluation_criteria" : row[3],
                    "evaluation_standard" : row[4],
                    "report_reference" : row[5],
                }
                row_content, columns = impl.run(data, overrides,tenant, env, approach, AZURE_WEB_URL,masterdata, openai_client=openai_client)
                finTime = time.time() - startTime
                output_rows.append(row_content)
            
                complete_df = pd.DataFrame(output_rows,columns = columns)
        
                UploadESGFile(self.blob_container, complete_df, thread_key, output_filename, overrides)
        except Exception as e:
            UpdateTmpFile(self.blob_container, overrides, input_filename, output_filename, thread_key, total_num_of_scheduled_tasks, total_num_of_completed_tasks, "partialcompletion",created)
            return

        ## すべての処理を終えたら一時ファイルのstatusをcompletionに変更します
        now = datetime.datetime.now()
        formatted_datetime = now.strftime("%Y%m%d_%H%M%S")
        self.handle_success_log(formatted_datetime, env, input_filename, output_filename, overrides, approach, tenant, thread_key)
        UpdateTmpFile(self.blob_container, overrides, input_filename, output_filename, thread_key, total_num_of_scheduled_tasks, total_num_of_scheduled_tasks, "completion",created)
        return


    def handle_success_log(self, dt:str, env:str, input_filename:str, output_filename :str, overrides:dict,  approach:str, tenant:str,  thread_key:str, **kwargs):
        """
        infoログを出力します。
        """
        # latestQueryはないのでいったん空文字で
        latestQuery = ""
        params = {
            "input_filename" : input_filename,
            "output_filename" : output_filename,
            "thread_key" : thread_key,
            "engine": self.chatgpt_deployment,
            "search_engine": self.search_engine,
            **kwargs
        }
        create_debug_querylog_info(dt, env, latestQuery, overrides, approach, tenant, **params)

    def ensure_openai_token(self):
            global openai_token
            global openai_4o_client
            if openai_token.expires_on < int(time.time()) - 60:
                openai_token = azure_credential.get_token("https://cognitiveservices.azure.com/.default")
                api_key = openai_token.token
                openai_4o_client = AzureOpenAI(
                    api_key=api_key,  
                    api_version=AZURE_OPENAI_API_VERSION,
                    base_url=f"https://{AZURE_OPENAI_SERVICE}.openai.azure.com/openai/",
                )