import os
import datetime
import pandas as pd
import config
import time
import logging
import unicodedata
from openai import AzureOpenAI
from elasticsearch import Elasticsearch
from azure.identity import DefaultAzureCredential
from azure.search.documents import SearchClient
from azure.storage.blob import BlobServiceClient
from esg_src.util.esg_getrelevantdocuments_es import GetRelevantDocumentsES
from esg_src.util.esg_getanswer import GetGptAnswer
from util.createkeywordcompletion import CreateKeywordCompletion
from esg_src.util.esg_createchatmessages import create_chat_messages
from esg_src.util.misc_functions import create_source_columns, create_report_filter_list, create_source_list
from util.logger import create_debug_conversationlog_info, create_debug_querylog_error, create_debug_querylog_info, get_chat_messages_as_text
from util.getencodingmodel import get_encoding_model

class ReadPrepRetrieveLLMTwice():
    
    def __init__(self, instance ):
        self.search_client =  instance.search_client
        self.search_index =  instance.search_index
        self.sourcepage_field =  instance.sourcepage_field
        
        self.blob_url = instance.blob_url
        self.further_question_score =  instance.further_question_score
        self.search_engine =  instance.search_engine
        self.fields = instance.fields
        self.content_field = instance.content_field
        self.chatgpt_deployment = instance.chatgpt_deployment
        self.embedding_deployment = instance.embedding_deployment
        self.retry_count = instance.retry_count
        self.retry_interval = instance.retry_interval
        self.chat_temperature = instance.chat_temperature
        self.system_prompt = instance.system_prompt
        self.prompt_template = instance.prompt_template
        self.output_max_token = instance.output_max_token
        self.blob_container = instance.blob_container
        self.approx_max_tokens = instance.approx_max_tokens
        self.token_threshold = instance.token_threshold
        
        self.default_columns = ["コード","会社名","重要項目","評価項目","評価基準","検索対象","該当有無","AI回答"]
        self.reference_columns = ["引用情報","url"]
        self.reporttype_list = ["有価証券報告書","統合報告書","コーポレートガバナンス報告書","サステナビリティレポート","ESGデータブック","中期経営計画"]
        self.judge_list = ["該当する","該当しない","判定不能"] 
            
    def run(self,data : dict, overrides: dict, tenant:str, env : str, approach : str, AZURE_WEB_URL:str , master_data:dict, openai_client:AzureOpenAI):
        try:

            dt = datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S")
            startTime1 = time.time()
            top = overrides.get("top") or 4
            
            # 出力用のカラム作成
            source_columns = create_source_columns(top, self.reference_columns)
            columns = self.default_columns+source_columns
            
            # 変数の取得/出力用の行情報作成
            ## 全角->半角、小文字->大文字
            _security_code = unicodedata.normalize("NFKC",str(data["security_code"]))
            _security_code =  0 if _security_code == "" else _security_code.upper() 
            try:
                security_code = str(int(float(_security_code))) 
            except:
                security_code = str(_security_code)
            key_issue = data["key_issue"]
            evaluation_criteria = data["evaluation_criteria"]
            evaluation_standard = data["evaluation_standard"]
            report_reference  = data["report_reference"]
            try:
                company_name = master_data[security_code]
            except:
                company_name = "invalid-security_code"
            source_row = [security_code, company_name, key_issue, evaluation_criteria, evaluation_standard, report_reference]


            #query生成
            query = f"トピック: {key_issue}、評価項目: {evaluation_criteria}、評価基準:{evaluation_standard}"
            history = [{"user":query}]
            step1elapsedTime = time.time() - startTime1

            history_create_search_keyword = [{"user" : key_issue+evaluation_criteria+evaluation_standard}]
            ## どのレポートタイプで検索フィルターをかけるか
            ## 空、あるいはよくわからない下記３種類以外が入っていた場合はすべてに対して検索をかけます
            self.report_filter_list = create_report_filter_list(report_reference, self.reporttype_list)
            self.security_code = security_code
        
        except Exception as e:
            logging.exception("Exception in before step1 ")
            raise

        ## キーワード生成
        ## 生成する際にはkey_issue, evaluate_criteria, evaluation_standardを単純に連結させたものを使用

        try:
            q = CreateKeywordCompletion().create_search_keyword(instance = self, 
                                                                history=history_create_search_keyword, 
                                                                overrides = overrides, 
                                                                tenant = tenant, 
                                                                approach=approach, 
                                                                env=env, 
                                                                dt=dt, 
                                                                startTime=startTime1, 
                                                                openai_client=openai_client)
        except Exception as e:
            params = {
                 "step1elapsedTime" : step1elapsedTime
            }
            create_debug_querylog_error(dt, env, query, overrides, approach, tenant, **params)

        ## 検索クエリの作成

        startTime2 = time.time()

        fulltext_search_query_body = self.get_fulltext_search_query_body(q,security_code, self.report_filter_list,self.fields)
        # ベクトル検索
        ## ベクトル検索はトピック：ｘｘｘ評価項目：ｘｘｘ評価基準：ｘｘｘ
        ## 全文検索は　生成したキーワードで検索

        try:
            relevant_documents, score = GetRelevantDocumentsES().get_relevant_documents(instance = self, top = top, overrides=overrides, q = query, fulltext_search_query_body=fulltext_search_query_body, get_vector_squery_body = self.get_vector_squery_body, tenant = tenant, approach = approach, env = env, latestQuery = query, dt = dt, startTime = startTime2, step1elapsedTime  = step1elapsedTime, openai_client=openai_client)
        except Exception as e:
            params = {
                 "step1elapsedTime" : step1elapsedTime,
                 "startTime2" : startTime2
            }
            create_debug_querylog_error(dt, env, query, overrides, approach, tenant, **params)


        #出力に載せるソース情報のリスト作成
        source_list = create_source_list(relevant_documents, AZURE_WEB_URL)

        # 空だったら無効な証券コードなので適切な行データを作成しこれ以降の処理は行わない
        ai_answer = "登録されていないコードです"
        ai_judge = "出力エラー"
        if relevant_documents == []:
             return source_row + [ai_judge,ai_answer]+[""]*top*len(self.reference_columns), columns



        step2elapsedTime=time.time() - startTime2

        ## すべて文書のトークン数が閾値より大きかったら、関連文書を減らしていく処理
        try:
            relevant_documents = self.reduce_token(relevant_documents, token_threshold=self.token_threshold)
        except Exception as e:
            logging.exception("Exception in reduce token")


        ##LLMに回答生成させる
        startTime3 = time.time()
        log_params = {
                "search":query.replace('\n', '<br>'), 
                "search_engine":self.search_engine,
                "3rd_score": score,
                "step1elapsedTime":step1elapsedTime,
                "step2elapsedTime":step2elapsedTime,
        }
        try:
            content = "\n".join(relevant_documents)
            prompt_template = "0"
            messages,len_flag = create_chat_messages(history, tenant, approach, self.chatgpt_deployment, prompt_template, content, approx_max_tokens=self.approx_max_tokens)
            if len_flag == 1:
                ai_answer = "OpenAI受け入れ文字数オーバーしました。入力文字数の見直しを行ってください。"
            else:
                ai_answer = GetGptAnswer().get_answer(instance=self, overrides=overrides, messages=messages, tenant=tenant, approach=approach, env=env, latestQuery=query, temperature=self.chat_temperature, max_tokens=self.output_max_token,approx_max_tokens = self.approx_max_tokens, dt=dt, startTime=startTime3,openai_client=openai_client, **log_params)
        except Exception as e:
            logging.exception("Exception in step3 create llm first answer")
            raise  
    
        try:
            prompt_template = "1"
            history = [{"user":ai_answer}]
            messages,len_flag = create_chat_messages(history, tenant, approach, self.chatgpt_deployment, prompt_template, "", approx_max_tokens=self.approx_max_tokens)
            if len_flag == 1:
                ai_judge = "OpenAI受け入れ文字数オーバーしました。入力文字数の見直しを行ってください。"
            else:
                ai_judge = GetGptAnswer().get_answer(instance=self, overrides=overrides, messages=messages, tenant=tenant, approach=approach, env=env, latestQuery=query, temperature=self.chat_temperature, max_tokens=self.output_max_token,approx_max_tokens = self.approx_max_tokens, dt=dt, startTime=startTime3, openai_client=openai_client, **log_params)
        except Exception as e:
            logging.exception("Exception in step3 create llm second answer")
            raise
    
        ##出力用にai_answerを一部修正
        index = ai_answer.find("\nA.")
        if index != -1:
             ai_answer_fix = ai_answer[index+4:]
        else:
             ai_answer_fix = ai_answer

        ##出力用にai_judgeを一部修正
        ai_judge_fix = "".join([l for l in self.judge_list if l in ai_judge]) 
        _ai_judge_fix =  ai_judge_fix if ai_judge_fix else "判定不能"

        #回答用のrowを作成する
        row_content = source_row+[_ai_judge_fix,ai_answer_fix]+source_list
             
        return row_content, columns


    def get_vector_squery_body(self, vector):
            query_body = { 
                "knn": [
                    {
                        "field": "content_vector",
                        "query_vector": vector,
                        "k": 50,
                        "num_candidates": 500,
                        "filter" : [{
                            "term" : {
                                "security_code.keyword" : self.security_code
                            }
                        },{
                            "terms" : {
                                "reporttype.keyword" : self.report_filter_list
                            }
                        }]
                    }
                ],
                "size":50
            }

            return query_body
    
    def get_fulltext_search_query_body(self, q:str, security_code:str, report_filter_list:list,field:list):
        query_body = { 
            "query": {
                "bool": {
                    "must": {
                        "multi_match": {
                            "query": q,
                            "fields": field
                        }
                    },
                    "filter": [
                         {
                        "term": {
                            "security_code.keyword": security_code
                        }
                         },
                         {
                        "terms" : {
                             "reporttype.keyword" : report_filter_list
                        }
                        }
                    ]
                }
            },
            "size": 50
        }
        return query_body
    
    def reduce_token(self, relevant_documents : list, token_threshold=14000 ):
        try:
            token_num = 0
            encoding_model = get_encoding_model(self.chatgpt_deployment)
            for documents in relevant_documents:
                token_num += len(encoding_model.encode(documents))
            if token_num > token_threshold:
                return self.reduce_token(relevant_documents[:-1], self.token_threshold)
            else:
                return relevant_documents
        except Exception as e:
            raise
