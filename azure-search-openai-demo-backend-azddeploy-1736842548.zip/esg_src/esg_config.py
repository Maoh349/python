import os
from elasticsearch import Elasticsearch

AZURE_STORAGE_ESG = os.environ.get("AZURE_STORAGE_ESG") or "esg"
AZURE_SEARCH_INDEX_ESG = os.environ.get("AZURE_SEARCH_INDEX_ESG") or "esg_index_20240318"
KB_FIELDS_CONTENT = os.environ.get("KB_FIELDS_CONTENT") or "content"
KB_FIELDS_CATEGORY = os.environ.get("KB_FIELDS_CATEGORY") or "category"
KB_FIELDS_SOURCEPAGE = os.environ.get("KB_FIELDS_SOURCEPAGE") or "sourcepage"
KB_FIELDS_BLOBURL = os.environ.get("KB_FIELDS_BLOBURL") or "blob_url"
AZURE_OPENAI_FIRST_DEPLOYMENT = os.environ.get("AZURE_OPENAI_FIRST_DEPLOYMENT") or "GPT16K"
AZURE_OPENAI_SECOND_DEPLOYMENT = os.environ.get("AZURE_OPENAI_SECOND_DEPLOYMENT") or "GPT-4o"
AZURE_OPENAI_EMBEDDING_DEPLOYMENT = os.environ.get("AZURE_OPENAI_EMBEDDING_DEPLOYMENT") or "text-embedding-ada-002"
AZURE_OPENAI_RETRY_COUNT = int(os.environ.get("AZURE_OPENAI_RETRY_COUNT") or "3")
AZURE_OPENAI_RETRY_INTERVAL = int(os.environ.get("AZURE_OPENAI_RETRY_INTERVAL") or "20")
AZURE_OPENAI_CHAT_TEMPERATURE = int(os.environ.get("AZURE_OPENAI_CHAT_TEMPERATURE") or "0")
MAX_THREAD_NUM = int(os.environ.get("MAX_THREAD_NUM") or "2")
THREAD_SLEEP_TIME = int(os.environ.get("THREAD_SLEEP_TIME") or "10")
AZURE_OPENAI_RETRY_COUNT_ESG = int(os.environ.get("AZURE_OPENAI_RETRY_COUNT_ESG") or "100")
AZURE_OPENAI_FIRST_MODEL_APPROX_MAX_TOKENS = int(os.environ.get("AZURE_OPENAI_FIRST_MODEL_APPROX_MAX_TOKENS") or "1000")
AZURE_OPENAI_SECOND_MODEL_APPROX_MAX_TOKENS = int(os.environ.get("AZURE_OPENAI_SECOND_MODEL_APPROX_MAX_TOKENS") or "20000")
AZURE_OPENAI_MODEL_TOKEN_THRESHOLD = int(os.environ.get("AZURE_OPENAI_MODEL_TOKEN_THRESHOLD") or "14000")


ELASTICSEARCH_SEARCH_APIKEY = os.environ.get("ELASTICSEARCH_SEARCH_APIKEY") or "apikey"
ELASTICSEARCH_SEARCH_SERVICE  = os.environ.get("ELASTICSEARCH_SEARCH_SERVICE") or "https://599c24a601144435b29cbca1ba8821c4.privatelink.japaneast.azure.elastic-cloud.com:9243"

ESG_SYSTEM_PROMPT = "あなたは、ドキュメントをもとに企業のESG情報を回答する事務AIです。回答条件は必ず守ること。"
ESG_PROMPT_TEMPLATE = [
            f"""
            以下の条件を守った上で、トピックに該当する###引用情報###の中から、評価項目についてドキュメントの情報を読み取り、評価基準に適合するかどうか及びその根拠を回答してください。
            回答を作成する際には###回答例１を参考にしなさい。

            ### 条件
            - 必ず一つ以上のドキュメントを出典として付与すること、出典を付与する際には回答を作成する際に参考にした部分の原文を載せること
            - 対象の項目に関するドキュメントが存在しない場合には「情報が開示されていない」と回答すること 
            - 評価に必要な情報が不足している場合には、「情報が不足している」と回答すること 
            - 評価基準に適合しているかどうかが最重要です。評価基準との適合性をしっかり見てください。 

            ----------
            ### 回答例１
            Q. トピック: 気候変動、評価項目: 脱炭素、評価基準: 炭素排出量削減目標が設定されている 
            A. <weather_00(Pxx-Pxx)>によると脱炭素に関する目標が明示されています。したがって、炭素排出量削減目標が設定されていると考えられます。 

            Q. トピック: 気候変動、評価項目: 認証取得、評価基準: 炭素排出量削減目標について外部認証を取得している 
            A. 外部認証取得に関する記載はありません。したがって、炭素排出量削減目標について外部認証を取得している情報は開示されていません。

            Q. トピック: 気候変動、評価項目: 炭素排出量削減率実績、評価基準:過去３年の平均削減率実績以上で開示がある 
            A. 過去３年の平均削減率実績に関する記載はありません。過去３年の平均削減率実績以上かどうかを判定するためには情報が不足しています。

            ### 引用情報例 ###
            - 0. @@@文書名:weather_00 @@@参考リンク:xxx @@@本文：2030年までに炭素排出量を50％削減（2013年対比）

            ----------
            ### 回答
            Q. $1
            A. ...

        """,
        f"""
        あなたは、ドキュメントをもとに企業のESG情報を回答する事務AIです。
        ###QAの内容から、評価基準に適合するかどうかを「“該当する”」「“該当しない”」のいずれかで回答してください。
        回答は上記の2択です。
        回答を作成する際には###回答例２を参考にしなさい.重要な点は、Qの中の評価基準の内容がAの内容と適合しているかどうかです。

        --------
        ###回答例２ 
        Q. トピック: 気候変動、評価項目: 脱炭素、評価基準: 炭素排出量削減目標が開示されている
        A. <weather_00(Pxx-Pxx)>によると「炭素排出量を2030年までに46%以上削減する」という記載があります。したがって、炭素排出量削減目標は設定されていると考えられます。
        あなたの回答：該当する

        Q. トピック: 気候変動、評価項目: 脱炭素、評価基準: 炭素排出量削減目標について外部認証を取得していることが開示されている
        A. <weather_00(Pxx-Pxx)>によると「炭素排出量削減目標に関して外部認証を取得している」という記載はありません。したがって、炭素排出量削減目標に関して外部認証は取得していないと考えられます。
        あなたの回答：該当しない

        Q. トピック: 気候変更、評価項目: 炭素排出量削減率実績、評価基準: 昨年の削減率実績が過去３年の平均削減率実績以上であることが開示されている
        A. <weather_00(Pxx-Pxx)>によると過去３年の炭素排出量削減実績率に関する開示がありません。したがって、昨年の排出量削減率実績が過去３年の平均削減率以上かどうかは確認できません。
        あなたの回答：該当しない

        ---------
        ###QAの内容
        $1
        """
        ]

search_client_es = Elasticsearch(
    ELASTICSEARCH_SEARCH_SERVICE,
    api_key=ELASTICSEARCH_SEARCH_APIKEY)

esg_config_list = {
    "esg" : {
            "search_client" : search_client_es, 
            "search_index" : AZURE_SEARCH_INDEX_ESG, 
            "storage" : AZURE_STORAGE_ESG,
            "sourcepage_field" : KB_FIELDS_SOURCEPAGE,
            "blob_url" : KB_FIELDS_BLOBURL,
            "content_field" : KB_FIELDS_CONTENT,
            "further_question_score" : 0,
            "search_engine" : "ES",
            "search_success_template" : "",
            "search_failed_template" : "",
            "fields": ["content"],
            "first_deployment" : AZURE_OPENAI_FIRST_DEPLOYMENT, 
            "second_deployment" : AZURE_OPENAI_SECOND_DEPLOYMENT,
            "embedding_deployment" : AZURE_OPENAI_EMBEDDING_DEPLOYMENT , 
            "retry_count" : AZURE_OPENAI_RETRY_COUNT_ESG,
            "retry_interval" : AZURE_OPENAI_RETRY_INTERVAL,
            "chat_temperature" : AZURE_OPENAI_CHAT_TEMPERATURE,
            "system_prompt" : ESG_SYSTEM_PROMPT,
            "prompt_template" : ESG_PROMPT_TEMPLATE,
            "output_max_token" : 1000,
            "max_thread_num" : MAX_THREAD_NUM,
            "thread_sleep_time" : THREAD_SLEEP_TIME,
            "first_model_approx_max_tokens": AZURE_OPENAI_FIRST_MODEL_APPROX_MAX_TOKENS,
            "second_model_approx_max_tokens": AZURE_OPENAI_SECOND_MODEL_APPROX_MAX_TOKENS,
            "token_threshold": AZURE_OPENAI_MODEL_TOKEN_THRESHOLD
    }
}