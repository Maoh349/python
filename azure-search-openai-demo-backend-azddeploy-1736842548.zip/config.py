import os
import mimetypes
import time
import logging
import urllib.parse
import json
import datetime
from flask import Flask, request, jsonify
from azure.identity import DefaultAzureCredential
from azure.search.documents import SearchClient
from elasticsearch import Elasticsearch
from conversations.deleteconversation import deleteConversationBlob, deletePastConversationBlob
from conversations.getconversation import retrieveUserConversation
from azure.core.credentials import AzureKeyCredential
from util.logger import output_log
from util.feedbackrecord import likeFeedbackUpdate
from util.feedbackrecord import dislikeFeedbackUpdate
from util.feedbackrecord import clickCountUpdate
from util.getanswer import GetGptAnswer
from util.createkeywordcompletion import CreateKeywordCompletion
from util.getrelevantdocuments_es import GetRelevantDocumentsES
from util.getrelevantdocuments_cs import GetRelevantDocumentsCS

#added by Shigeki for local build
mimetypes.add_type('application/javascript', '.js')
mimetypes.add_type('text/css', '.css')

# Replace these with your own values, either in environment variables or directly here
# If you want to swap environment vairables for a staging environment, configure on Azure portal. Do not edit these below. by Shigeki
AZURE_SEARCH_SERVICE = os.environ.get("AZURE_SEARCH_SERVICE") or "gptkb"
ELASTICSEARCH_SEARCH_APIKEY = os.environ.get("ELASTICSEARCH_SEARCH_APIKEY") or "apikey"
ELASTICSEARCH_SEARCH_SERVICE  = os.environ.get("ELASTICSEARCH_SEARCH_SERVICE") or "https://599c24a601144435b29cbca1ba8821c4.privatelink.japaneast.azure.elastic-cloud.com:9243"
AZURE_SEARCH_INDEX = os.environ.get("AZURE_SEARCH_INDEX") or "gptindex-ailias"
AZURE_SEARCH_INDEX_C = os.environ.get("AZURE_SEARCH_INDEX_C") or "test_gptkbindex-kujyouu-only_importantkeyword_summary_1536vector_question_add_renewqa_2"
AZURE_SEARCH_INDEX_RTO = os.environ.get("AZURE_SEARCH_INDEX_RTO") or "test_gptlbindex-omousshide-only-pdfchunk_1536vector_add_renewqa_0220_1536vector"
AZURE_SEARCH_INDEX_LWF = os.environ.get("AZURE_SEARCH_INDEX_LWF") or "test_syojyou_workflow_new_1536vector_20240303_5"
AZURE_SEARCH_INDEX_FAQ = os.environ.get("AZURE_SEARCH_INDEX_FAQ") or "test_kojin_faq_qa_20231120_only_1536vector"
AZURE_SEARCH_INDEX_FAQ_MY = os.environ.get("AZURE_SEARCH_INDEX_FAQ_MY") or "test_my_faq_qa_20231128_only_1536vector"
AZURE_SEARCH_INDEX_GPS = os.environ.get("AZURE_SEARCH_INDEX_GPS") or "test_dantai_nenkin_20240228" 
AZURE_OPENAI_SERVICE = os.environ.get("AZURE_OPENAI_SERVICE") or "myopenai_us"
AZURE_OPENAI_FIRST_DEPLOYMENT = os.environ.get("AZURE_OPENAI_FIRST_DEPLOYMENT") or "GPT16K"
AZURE_OPENAI_SECOND_DEPLOYMENT = os.environ.get("AZURE_OPENAI_SECOND_DEPLOYMENT") or "GPT-4o"
AZURE_OPENAI_EMBEDDING_DEPLOYMENT = os.environ.get("AZURE_OPENAI_EMBEDDING_DEPLOYMENT") or "text-embedding-ada-002"
AZURE_OPENAI_RETRY_COUNT = int(os.environ.get("AZURE_OPENAI_RETRY_COUNT") or "3")
AZURE_OPENAI_RETRY_INTERVAL = int(os.environ.get("AZURE_OPENAI_RETRY_INTERVAL") or "10")
AZURE_OPENAI_CHAT_TEMPERATURE = int(os.environ.get("AZURE_OPENAI_CHAT_TEMPERATURE") or "0")
AZURE_OPENAI_CS_TEMPERATURE = int(os.environ.get("AZURE_OPENAI_CS_TEMPERATURE") or "0")
AZURE_OPENAI_FIRST_MODEL_APPROX_MAX_TOKENS = int(os.environ.get("AZURE_OPENAI_FIRST_MODEL_APPROX_MAX_TOKENS") or "1000")
AZURE_OPENAI_SECOND_MODEL_APPROX_MAX_TOKENS = int(os.environ.get("AZURE_OPENAI_SECOND_MODEL_APPROX_MAX_TOKENS") or "20000")

KB_FIELDS_CONTENT = os.environ.get("KB_FIELDS_CONTENT") or "content"
KB_FIELDS_CATEGORY = os.environ.get("KB_FIELDS_CATEGORY") or "category"
KB_FIELDS_SOURCEPAGE = os.environ.get("KB_FIELDS_SOURCEPAGE") or "sourcepage"
KB_FIELDS_BLOBURL = os.environ.get("KB_FIELDS_BLOBURL") or "blob_url"

FURTHER_QUESTION_SCORE = int(os.environ.get("FURTHER_QUESTION_SCORE") or "0")
APP_ENVIRONMENT = os.environ.get("APP_ENVIRONMENT") or "honban"

SEARCH_ENGINE_ELASTICSEARCH = "ES"
SEARCH_ENGINE_COGNITIVE_SEARCH = "CS"

# Use the current user identity to authenticate with Azure OpenAI, Cognitive Search and Blob Storage (no secrets needed, 
# just use 'az login' locally, and managed identity when deployed on Azure). If you need to use keys, use separate AzureKeyCredential instances with the 
# keys for each service
# If you encounter a blocking error during a DefaultAzureCredntial resolution, you can exclude the problematic credential by using a parameter (ex. exclude_shared_token_cache_credential=True)
azure_credential = DefaultAzureCredential()

# Set up clients for Cognitive Search and Storage
search_client_cs = SearchClient(
    endpoint=f"https://{AZURE_SEARCH_SERVICE}.search.windows.net",
    index_name=AZURE_SEARCH_INDEX,
    credential=azure_credential)
search_client_es = Elasticsearch(
    ELASTICSEARCH_SEARCH_SERVICE,
    api_key=ELASTICSEARCH_SEARCH_APIKEY)

# エンドポイントの新規追加はここにしてください
# "preprocess_instance" : STEP1の有無、有->関数のインスタンス 無->False
# "search_instance" : STEP2の有無、有->関数のインスタンス 無->False
# "create_llm_answer_instance" : STEP3の有無、有->関数のインスタンス 無->False

api_config_list = {
    "chat" : {
        "preprocess_instance" : False,
        "search_instance" : False,
        "create_llm_answer_instance" : GetGptAnswer()
    },
    "searchAndAnswer" : {
        "preprocess_instance" : CreateKeywordCompletion(),
        "search_instance" : GetRelevantDocumentsES(),
        "create_llm_answer_instance" : GetGptAnswer()
    },
    "searchOnly" : {
        "preprocess_instance" : CreateKeywordCompletion(),
        "search_instance" : GetRelevantDocumentsES(),
        "create_llm_answer_instance" : False
    },
    "answerRegenerate" : {
        "preprocess_instance" : False,
        "search_instance" : False,
        "create_llm_answer_instance" : GetGptAnswer()
    },
    "answerWithSelectedData" : {
        "preprocess_instance" : False,
        "search_instance" : False,
        "create_llm_answer_instance" : GetGptAnswer()
    }
}



# approachの新規追加はここにしてください
# "search_client" : 検索エンジンのインスタンス 
# "search_index" : 検索エンジンのインデックス名
# "sourcepage_field" : blobのソースの格納先
# "content_field" :　blobデータの格納先
# "blob_url" : blobのURL
# "further_question_score" : 検索の際の閾値に使用するスコア
# "search_engine" : 検索エンジンの種類（ESorCS）
# "search_success_template" : 検索したときに関連文書があった場合のメッセージ
# "search_failed_template" : 検索した時に関連文書がなかった場合のメッセージ
# "fields": [], 検索エンジンに入れるfields
# "first_deployment" : LLMの回答作成に使用するgpt3.5モデル
# "second_deployment" : LLMの回答作成に使用するgpt-4oモデル
# "embedding_deployment" : embeddingに使うモデル 
# "retry_count" : リトライ回数
# "retry_interval" : リトライ間隔
# "chat_temperature" : GPTの出力制御
# "system_prompt" : システムプロンプト
# "prompt_template" :　プロンプトに入力かませるプロンプト
# "output_max_token" : LLMの出力のトークン数上限


config_list = {
    # LLMの回答だけ作成　通常のチャット
    "crrr" : {
        "search_client" : None, 
        "search_index" : None, 
        "sourcepage_field" : None,
        "content_field" : None,
        "blob_url" : None,
        "further_question_score" : None,
        "search_engine" : None,
        "search_success_template" : "",
        "search_failed_template" : "",
        "fields": None, 
        "first_deployment" : AZURE_OPENAI_FIRST_DEPLOYMENT, 
        "second_deployment":AZURE_OPENAI_SECOND_DEPLOYMENT,
        "embedding_deployment" : None, 
        "retry_count" : AZURE_OPENAI_RETRY_COUNT,
        "retry_interval" : AZURE_OPENAI_RETRY_INTERVAL,
        "chat_temperature" : AZURE_OPENAI_CHAT_TEMPERATURE,
        "system_prompt" : "",
        "prompt_template" : "",
        "output_max_token" : 2048,
        "second_model_approx_max_tokens": AZURE_OPENAI_SECOND_MODEL_APPROX_MAX_TOKENS,
        "first_model_approx_max_tokens": AZURE_OPENAI_FIRST_MODEL_APPROX_MAX_TOKENS,
    },
    # LLMの回答だけ作成、CSの2回目以降の返答に作成
    "crrras" : {
        "search_client" : None, 
        "search_index" : None, 
        "sourcepage_field" : None,
        "content_field" : None,
        "blob_url" : None,
        "further_question_score" : None,
        "search_engine" : None,
        "search_success_template" : "",
        "search_failed_template" : "",
        "fields": None,
        "first_deployment" : AZURE_OPENAI_FIRST_DEPLOYMENT, 
        "second_deployment":AZURE_OPENAI_SECOND_DEPLOYMENT,
        "embedding_deployment" : None, 
        "retry_count" : AZURE_OPENAI_RETRY_COUNT,
        "retry_interval" : AZURE_OPENAI_RETRY_INTERVAL,
        "chat_temperature" : AZURE_OPENAI_CHAT_TEMPERATURE,
        "system_prompt" : "",
        "prompt_template" : "",
        "output_max_token" : 1024,
        "first_model_approx_max_tokens": AZURE_OPENAI_FIRST_MODEL_APPROX_MAX_TOKENS,
        "second_model_approx_max_tokens": AZURE_OPENAI_SECOND_MODEL_APPROX_MAX_TOKENS
    },
    # キーワード生成、検索して出力　書状WFで使用
    "rrrlwff" : {
        "search_client" : search_client_es, 
        "search_index" : AZURE_SEARCH_INDEX_LWF, 
        "sourcepage_field" : KB_FIELDS_SOURCEPAGE,
        "content_field" : KB_FIELDS_CONTENT,
        "blob_url" : KB_FIELDS_BLOBURL,
        "further_question_score" : FURTHER_QUESTION_SCORE,
        "search_engine" : SEARCH_ENGINE_ELASTICSEARCH,
        "search_success_template" : "以下、関連度が高い回答例文を見つけました。\n",
        "search_failed_template" : "申し訳ございません。関連度が高い回答例文が見つかりませんでした。",
        "fields": [ "content^10", "mykeyword^5","filetype","gyoumu_lv1^1","gyoumu_lv2^1","gyoumu_lv3^1","yakkan","finacial_year","GeneratedSummary^10","relatedQuestions^10" ],
        "first_deployment" : AZURE_OPENAI_FIRST_DEPLOYMENT, 
        "second_deployment":AZURE_OPENAI_SECOND_DEPLOYMENT,
        "embedding_deployment" : AZURE_OPENAI_EMBEDDING_DEPLOYMENT , 
        "retry_count" : AZURE_OPENAI_RETRY_COUNT,
        "retry_interval" : AZURE_OPENAI_RETRY_INTERVAL,
        "chat_temperature" : AZURE_OPENAI_CHAT_TEMPERATURE,
        "system_prompt" : "",
        "prompt_template" : "",
        "output_max_token" : None,
        "first_model_approx_max_tokens": AZURE_OPENAI_FIRST_MODEL_APPROX_MAX_TOKENS,
        "second_model_approx_max_tokens": AZURE_OPENAI_SECOND_MODEL_APPROX_MAX_TOKENS
    },
    # キーワード生成、検索して出力、検索結果を利用してLLMが回答作成、CSで使用
    "rrrmixc" : {
        "search_client" : search_client_es, 
        "search_index" : AZURE_SEARCH_INDEX_C, 
        "sourcepage_field" : KB_FIELDS_SOURCEPAGE,
        "content_field" : KB_FIELDS_CONTENT,
        "blob_url" : KB_FIELDS_BLOBURL,
        "further_question_score" : FURTHER_QUESTION_SCORE,
        "search_engine" : SEARCH_ENGINE_ELASTICSEARCH,
        "search_success_template" : "",
        "search_failed_template" : "申し訳ございません。引用先に情報がありません。",
        "fields": [ "content^10", "mykeyword^5","filetype","gyoumu_lv1^1","gyoumu_lv2^1","gyoumu_lv3^1","yakkan","finacial_year","GeneratedSummary^10","relatedQuestions^10" ],
        "first_deployment" : AZURE_OPENAI_FIRST_DEPLOYMENT, 
        "second_deployment":AZURE_OPENAI_SECOND_DEPLOYMENT,
        "embedding_deployment" : AZURE_OPENAI_EMBEDDING_DEPLOYMENT , 
        "retry_count" : AZURE_OPENAI_RETRY_COUNT,
        "retry_interval" : AZURE_OPENAI_RETRY_INTERVAL,
        "chat_temperature" : AZURE_OPENAI_CHAT_TEMPERATURE,
        "system_prompt" : "あなたは生命保険会社の業務に関する質問に答えるヘルプデスクです。\n以下の条件に則りマークダウン形式で回答を生成してください。ただし、注釈は使用しないで下さい。\n\n###条件###\n・質問に対してなるべく引用情報のテキストを利用して回答を生成してください。\n・質問に関連する引用情報がない場合は、学習データをもとに回答してください。\n・回答には、回答文と引用した文書名を必ず記載してください。\n・引用情報から作成した回答には2個の※マークで引用した文書名の情報を囲って記載してください。\n  例えばinfo1.pdf (P1 - P2)という文書を基に「書面による確認や電話確認などを行うことができます。」という回答を生成した場合は、\n  書面による確認や電話確認などを行うことができます。※※info1.pdf (P1 - P2)※※のように回答してください。※※文書名：info1.pdf (P1 - P2)※※といった書き方はしないでください。\n・引用情報が複数ある場合、それぞれ分けて文書名を記載してください。\n  例えば※※info1.pdf (P3 - P4)※※,※※info2.pdf (P3 - P10)※※,※※info3.pdf (P80 - P100)※※ のように回答してください\n・info.pdfに類似する引用情報は使用しないでください。\n・あなたの回答は、全体で1400文字以内で回答できるようにまとめてください。",
        "prompt_template" : [
        "お客さまからの問い合わせをいただいています。\n問い合わせに対して以下の条件で回答文書を作成してください。\n\n###問い合わせ：\n$1\n\n###条件：\n・あなたは支社の苦情対応責任者です。\n・社内の苦情対応の事例から情報を引用してください。\n・引用情報の本文に、苦情対応事例に対して<事実確認>、<最終対応>、<同種案件に対する対応>が記載されています。\n・社内の苦情対応の事例から、問い合わせと関連する事例の情報だけを使って以下の回答を作成してください。\n\n###回答：\n以下の形式で回答してください。\n### 【関連事例の概要】\n<関連する苦情対応の事例からお申し出内容概要と経緯を整理>\n### 【対応方針・内容】\n<関連する苦情対応の事例における<同種案件に対する対応の内容>を踏まえて、今回の問い合わせに対する対応の基本的な考え方・方針を立てる。かつ、対応すべき事項を5項目に絞って起案>\n### 【回答文案】\n<今回の問い合わせに関する、お客さまあての回答状の文案を800文字以内で作成>",
        "お客さまからの問い合わせをいただいています。\n問い合わせに対して以下の条件で回答文書を作成してください。\n\n###問い合わせ：\n$1\n\n###条件：\n・あなたは支社の苦情対応責任者です。\n・社内の苦情対応の事例から情報を引用してください。\n・引用情報の本文に、苦情対応事例に対して<事実確認>、<最終対応>、<同種案件に対する対応>が記載されています。\n・社内の苦情対応の事例から、問い合わせと関連する事例の情報だけを使って以下の回答を作成してください。\n\n###回答：\n以下の形式で回答してください。\n### 【関連事例の概要】\n<関連する苦情対応の事例からお申し出内容概要と経緯を整理>\n### 【対応方針・内容】\n<関連する苦情対応の事例における<同種案件に対する対応の内容>を踏まえて、今回の問い合わせに対する対応の基本的な考え方・方針を立てる。かつ、対応すべき事項を5項目に絞って起案>",
        "お客さまからの問い合わせをいただいています。\n問い合わせに対して以下の条件に従って作成内容を作成してください。\n\n###問い合わせ：\n$1\n\n###条件：\n・あなたは支社の苦情対応責任者です。\n・社内の苦情対応の事例から情報を引用してください。\n・引用情報の本文に、苦情対応事例に対して<事実確認>、<最終対応>、<同種案件に対する対応>が記載されています。\n・社内の苦情対応の事例から、問い合わせと関連する事例の情報だけを使って以下の回答を作成してください。\n\n###回答：\n以下の形式で回答してください。\n### 【関連事例の概要】\n<類似する苦情対応の事例からお申し出内容概要と経緯を整理>\n### 【回答文案】\n<今回の問い合わせに関する、お客さまあての回答状の文案を800文字以内で作成>"
        ],
        "output_max_token" : 1600,
        "first_model_approx_max_tokens": AZURE_OPENAI_FIRST_MODEL_APPROX_MAX_TOKENS,
        "second_model_approx_max_tokens": AZURE_OPENAI_SECOND_MODEL_APPROX_MAX_TOKENS
    },
    # キーワード生成、検索して出力、検索結果を利用してLLMが回答作成、CSで使用
    "rrrmixrto" : {
        "search_client" : search_client_es, 
        "search_index" : AZURE_SEARCH_INDEX_RTO, 
        "sourcepage_field" : KB_FIELDS_SOURCEPAGE,
        "content_field" : KB_FIELDS_CONTENT,
        "blob_url" : KB_FIELDS_BLOBURL,
        "further_question_score" : FURTHER_QUESTION_SCORE,
        "search_engine" : SEARCH_ENGINE_ELASTICSEARCH,
        "search_success_template" : "",
        "search_failed_template" : "申し訳ございません。引用先に情報がありません。",
        "fields": [ "content^10", "mykeyword^5","filetype","gyoumu_lv1^1","gyoumu_lv2^1","gyoumu_lv3^1","yakkan","finacial_year","GeneratedSummary^10","relatedQuestions^10" ],
        "first_deployment" : AZURE_OPENAI_FIRST_DEPLOYMENT, 
        "second_deployment":AZURE_OPENAI_SECOND_DEPLOYMENT,
        "embedding_deployment" : AZURE_OPENAI_EMBEDDING_DEPLOYMENT , 
        "retry_count" : AZURE_OPENAI_RETRY_COUNT,
        "retry_interval" : AZURE_OPENAI_RETRY_INTERVAL,
        "chat_temperature" : AZURE_OPENAI_CHAT_TEMPERATURE,
        "system_prompt" : "あなたは生命保険会社の業務に関する質問に答えるヘルプデスクです。\n以下の条件に則りマークダウン形式で回答を生成してください。ただし、注釈は使用しないで下さい。\n\n###条件###\n・質問に対してなるべく引用情報のテキストを利用して回答を生成してください。\n・質問に関連する引用情報がない場合は、学習データをもとに回答してください。\n・回答には、回答文と引用した文書名を必ず記載してください。\n・引用情報から作成した回答には2個の※マークで引用した文書名の情報を囲って記載してください。\n  例えばinfo1.pdf (P1 - P2)という文書を基に「書面による確認や電話確認などを行うことができます。」という回答を生成した場合は、\n  書面による確認や電話確認などを行うことができます。※※info1.pdf (P1 - P2)※※のように回答してください。※※文書名：info1.pdf (P1 - P2)※※といった書き方はしないでください。\n・引用情報が複数ある場合、それぞれ分けて文書名を記載してください。\n  例えば※※info1.pdf (P3 - P4)※※,※※info2.pdf (P3 - P10)※※,※※info3.pdf (P80 - P100)※※ のように回答してください\n・info.pdfに類似する引用情報は使用しないでください。\n・あなたの回答は、全体で1400文字以内で回答できるようにまとめてください。",
        "prompt_template" : [
        "お客さまから問い合わせをいただいています。\n問い合わせに対して以下の条件に従って回答文書を作成してください。\n\n###問い合わせ：\n$1\n\n###条件：\n・あなたは保険に関する問い合わせの回答責任者です。\n・お客さまあて回答文書を800文字以内で作成してください。\n・引用情報はお客さまの問い合わせに対する回答例文です。\n・回答例文の中から問い合わせと関連する例文の情報だけを使って回答を作成してください。\n・冒頭に拝啓、末尾に敬具をつけてください。\n・お問い合わせ先の情報をつけてください。\n\n###回答：\n<回答文書>",
        """お客さまから問い合わせをいただいています。\n問い合わせに対して以下の制約のもと、回答例文フォーマットの形式に従って回答文を作成してください。\n###制約\n・回答例文フォーマットの中の<<>>で囲まれた部分以外はそのまま記載してください。\n・回答例文フォーマットの中の<<>>で囲まれた部分に関して、<<>>の内に記載した指示に従って内容を生成して記載してください。\n・回答は文書を引用する形ではなく、引用情報から回答を生成してください。ただし、引用情報によると...のような書き方はしないでください。\n\n###問い合わせ\n$1\n\n###回答例文フォーマット\n****様\n\n明治安田生命保険相互会社\n******\n\n拝啓平素は格別のお引立てを賜り、厚くお礼申しあげます。\n\n●●様のご傷病につきましては、心よりお見舞い申しあげます。\n\n<<ここに問い合わせに対するお客様への理解を示す挨拶文を記載してください>>\n\n<<ここに問い合わせに対する回答の概要を生成して記載してください>>\n\n本状にて、下記のとおりご回答をさせていただきます。\n何とぞ、ご理解とご了承を賜りますようお願い申しあげます。\n\n<<ここに"敬具"と記載してください>>\n<<ここに"記"と記載してください>>\n\n１．対象となるご契約の概要\n・保険証券番号：第**-******号\n・ご契約者様：****様\n・ご契約日：****年**月**日\n・被保険者様：****様\n・保険種類：******\n・主契約:*********\n\n２．お申し出の内容は、次のとおりと認識しております。\n\n<<ここに問い合わせに対しての内容の理解を文章で記載してください>>\n\n３．上記お申し出につきまして、以下のとおりご回答申しあげます。\n\n<<ここに問い合わせに対する回答を参考文書をもとに作成し、①：,②：,③：...の形式の箇条書きで記載してください>>\n\n末筆ではございますが、●●様のご健勝を心より祈念申しあげます。\n以上\n\n＜本件に関するお問い合わせ先＞\n**支社\nお客さま志向推進部長****\n電話\n**-****-****""",
        """お客さまから問い合わせをいただいています。\n問い合わせに対して以下の制約のもと、回答例文フォーマットの形式に従って回答文を作成してください。\n###制約\n・回答例文フォーマットの中の<<>>で囲まれた部分以外はそのまま記載してください。\n・回答例文フォーマットの中の<<>>で囲まれた部分に関して、<<>>の内に記載した指示に従って内容を生成して記載してください。\n・回答は文書を引用する形ではなく、引用情報から回答を生成してください。ただし、引用情報によると...のような書き方はしないでください。\n\n###問い合わせ\n$1\n\n###回答例文フォーマット\n****様\n\n明治安田生命保険相互会社\n******\n\n拝啓ますますご清祥のこととお喜び申しあげます。\n平素は格別のお引き立てを賜り、厚くお礼申しあげます。\n\nさて、●年●月●日に●●が訪問した際、●●様のご契約（証券番号：第**-******号）の●●に関するお申し出を承りました。\nつきましては、以下のとおりご回答申しあげますので、何とぞご理解とご了承を賜りますようお願い申しあげます。\n末筆ではございますが、●●様のますますのご健勝を祈念申し上げます。\n\n<<ここに"敬具"と記載してください>>\n<<ここに"記"と記載してください>>\n\n<<ここに問い合わせの内容を記載してください。>>\n\n<<ここに問い合わせに対する回答を引用情報をもとに生成し記載してください。>>\n\n以上、●●様におかれましては、長年ご継続を賜っているにもかかわらず、貴意に反するご対応となりましたことを心よりお詫び申しあげます。\n何とぞ、ご理解とご了承を賜りますようお願い申しあげます。\n\n＜本件に関するお問い合わせ先＞\n**支社\nお客さま志向推進部長****\n電話\n**-****-****"""
        ],
        "output_max_token" : 1600,
        "first_model_approx_max_tokens": AZURE_OPENAI_FIRST_MODEL_APPROX_MAX_TOKENS,
        "second_model_approx_max_tokens": AZURE_OPENAI_SECOND_MODEL_APPROX_MAX_TOKENS
    },
    # キーワード生成、検索して出力、faqで使用  
    "rrrf" : {
        "search_client" : search_client_es, 
        "search_index" : AZURE_SEARCH_INDEX_FAQ, 
        "sourcepage_field" : KB_FIELDS_SOURCEPAGE,
        "content_field" : KB_FIELDS_CONTENT,
        "blob_url" : KB_FIELDS_BLOBURL,
        "further_question_score" : FURTHER_QUESTION_SCORE,
        "search_engine" : SEARCH_ENGINE_ELASTICSEARCH,
        "search_success_template" : "以下、関連度が高いFAQを見つけました。\n",
        "search_failed_template" :  "申し訳ございません。関連度が高いFAQが見つかりませんでした。",
        "fields": [ "content^10", "mykeyword^5","filetype","gyoumu_lv1^1","gyoumu_lv2^1","gyoumu_lv3^1","yakkan","finacial_year","GeneratedSummary^10","relatedQuestions^10" ],
        "first_deployment" : AZURE_OPENAI_FIRST_DEPLOYMENT,
        "second_deployment":AZURE_OPENAI_SECOND_DEPLOYMENT,
        "embedding_deployment" : AZURE_OPENAI_EMBEDDING_DEPLOYMENT , 
        "retry_count" : AZURE_OPENAI_RETRY_COUNT,
        "retry_interval" : AZURE_OPENAI_RETRY_INTERVAL,
        "chat_temperature" : AZURE_OPENAI_CHAT_TEMPERATURE,
        "system_prompt" : "",
        "prompt_template" : "",
        "output_max_token" : None,
        "first_model_approx_max_tokens": AZURE_OPENAI_FIRST_MODEL_APPROX_MAX_TOKENS,
        "second_model_approx_max_tokens": AZURE_OPENAI_SECOND_MODEL_APPROX_MAX_TOKENS
    },
    # キーワード生成、検索して出力、myfaqで使用  
    "rrrfmy" : {
        "search_client" : search_client_es, 
        "search_index" : AZURE_SEARCH_INDEX_FAQ_MY, 
        "sourcepage_field" : KB_FIELDS_SOURCEPAGE,
        "content_field" : KB_FIELDS_CONTENT,
        "blob_url" : KB_FIELDS_BLOBURL,
        "further_question_score" : FURTHER_QUESTION_SCORE,
        "search_engine" : SEARCH_ENGINE_ELASTICSEARCH,
        "search_success_template" : "以下、関連度が高いFAQを見つけました。\n",
        "search_failed_template" :  "申し訳ございません。関連度が高いFAQが見つかりませんでした。",
        "fields": [ "content^10", "mykeyword^5","filetype","gyoumu_lv1^1","gyoumu_lv2^1","gyoumu_lv3^1","yakkan","finacial_year","GeneratedSummary^10","relatedQuestions^10" ],
        "first_deployment" : AZURE_OPENAI_FIRST_DEPLOYMENT, 
        "second_deployment":AZURE_OPENAI_SECOND_DEPLOYMENT,
        "embedding_deployment" : AZURE_OPENAI_EMBEDDING_DEPLOYMENT , 
        "retry_count" : AZURE_OPENAI_RETRY_COUNT,
        "retry_interval" : AZURE_OPENAI_RETRY_INTERVAL,
        "chat_temperature" : AZURE_OPENAI_CHAT_TEMPERATURE,
        "system_prompt" : "",
        "prompt_template" : "",
        "output_max_token" : None,
        "first_model_approx_max_tokens": AZURE_OPENAI_FIRST_MODEL_APPROX_MAX_TOKENS,
        "second_model_approx_max_tokens": AZURE_OPENAI_SECOND_MODEL_APPROX_MAX_TOKENS
    },
    # LLMが回答生成、書状WFの関連文書選択後に回答生成
    "rrrlwff_a" : {
        "search_client" : search_client_es,  # feedback送るために必要,feedbackのロジック変えたらここも変更また変わる
        "search_index" : AZURE_SEARCH_INDEX_LWF, 
        "sourcepage_field" : None,
        "content_field" : None,
        "blob_url" : None,
        "further_question_score" : None,
        "search_engine" : None,
        "search_success_template" : "",
        "search_failed_template" : "",
        "fields": None,
        "first_deployment" : AZURE_OPENAI_FIRST_DEPLOYMENT,
        "second_deployment":AZURE_OPENAI_SECOND_DEPLOYMENT, 
        "embedding_deployment" : None , 
        "retry_count" : AZURE_OPENAI_RETRY_COUNT,
        "retry_interval" : AZURE_OPENAI_RETRY_INTERVAL,
        "chat_temperature" : AZURE_OPENAI_CHAT_TEMPERATURE,
        "system_prompt" :  "あなたは生命保険会社の業務に関する質問に答えるヘルプデスクです。\n以下の条件に則りマークダウン形式で回答を生成してください。ただし、注釈は使用しないで下さい。\n\n**条件**:\n・質問に対してなるべく引用情報のテキストを利用して回答を生成してください。\n・質問に関連する引用情報がない場合は、学習データをもとに回答してください。\n・回答には、回答文と引用した文書名を必ず記載してください。文書名は引用情報の@@@文書名:の直後の部分のことです。@@@参考リンクや@@@本文等は記載してはいけません。\n・引用情報から作成した回答には2個の※マークで引用した文書名を囲って記載してください。それは引用部分の直後に記載してください。\n  例えば'-契約者変更（法人）---法人へ契約者変更 契約者を法人へ変更したいと申し出がありました。手続き方法を教えてください。' という質問を基に「書面による確認や電話確認などを行うことができます。」という回答を生成した場合は、\n  書面による確認や電話確認などを行うことができます。※※3. -契約者変更（法人）---法人へ契約者変更 契約者を法人へ変更したいと申し出がありました。手続き方法を教えてください。※※ のように回答してください。\n・引用情報が複数ある場合、次のようにそれぞれ分けて文書名を記載してください。\n ※※3. -契約者変更（法人）---法人へ契約者変更 契約者を法人へ変更したいと申し出がありました。手続き方法を教えてください。※※,※※契約者死亡---名義変更請求書請求者欄の記入者 契約者死亡による契約者変更です。名義変更請求書の請求者欄について教えてください。※※,※※契約者死亡---手続き途中に契約者（被保険者）死亡 名義変更の申し出がありましたが、手続き途中で契約者（被保険者）が死亡しました。対応方法を教えてください。※※ \n・info.pdfに類似する引用情報は使用しないでください。\n・あなたの回答は、全体で1400文字以内で回答できるようにまとめてください。",
        "prompt_template" : [
        "問合せを引用情報に対して以下の追加条件に従って回答文書を作成してください。\n\n**追加指示**：\n$1\n\n**追加条件**：\n・引用情報は問い合わせに関連する情報です。\n・引用情報の中から問い合わせと関連する情報だけを使って回答を作成してください。\n・引用情報、問い合わせおよび追加指示を使って回答を作成してください。\n・回答の最後にまとめて引用情報を記載しないでください\n\n**回答**：\n<回答文書>"
        ],
        "output_max_token" : 1024,
        "first_model_approx_max_tokens": AZURE_OPENAI_FIRST_MODEL_APPROX_MAX_TOKENS,
        "second_model_approx_max_tokens": AZURE_OPENAI_SECOND_MODEL_APPROX_MAX_TOKENS
    },
    # アップロードしたファイル対してLLMが回答生成
    "crrrfu" : {
        "search_client" : None, 
        "search_index" : None,  
        "sourcepage_field" : None,
        "content_field" : None,
        "blob_url" : None,
        "further_question_score" : None,
        "search_engine" : None,
        "search_success_template" :"",
        "search_failed_template" : "",
        "fields": None,
        "first_deployment" : AZURE_OPENAI_FIRST_DEPLOYMENT, 
        "second_deployment":AZURE_OPENAI_SECOND_DEPLOYMENT,
        "embedding_deployment" : None, 
        "retry_count" : AZURE_OPENAI_RETRY_COUNT,
        "retry_interval" : AZURE_OPENAI_RETRY_INTERVAL,
        "chat_temperature" : AZURE_OPENAI_CHAT_TEMPERATURE,
        "system_prompt" :  "",
        "prompt_template" : "",
        "output_max_token" : 9000,
        "first_model_approx_max_tokens": AZURE_OPENAI_FIRST_MODEL_APPROX_MAX_TOKENS,
        "second_model_approx_max_tokens": AZURE_OPENAI_SECOND_MODEL_APPROX_MAX_TOKENS
    },
    # キーワード生成、検索して出力、検索結果を利用してLLMが回答作成、団体年金で使用
    "rrrmixgps" : {
        "search_client" : search_client_es, 
        "search_index" : AZURE_SEARCH_INDEX_GPS, 
        "sourcepage_field" : KB_FIELDS_SOURCEPAGE,
        "content_field" : KB_FIELDS_CONTENT,
        "blob_url" : KB_FIELDS_BLOBURL,
        "further_question_score" : FURTHER_QUESTION_SCORE,
        "search_engine" : SEARCH_ENGINE_ELASTICSEARCH,
        "search_success_template" : "",
        "search_failed_template" : "申し訳ございません。引用先に情報がありません。",
        "fields": [ "content^10", "mykeyword^5","filetype","gyoumu_lv1^1","gyoumu_lv2^1","gyoumu_lv3^1","yakkan","finacial_year","GeneratedSummary^10","relatedQuestions^10" ],
        "first_deployment" : AZURE_OPENAI_FIRST_DEPLOYMENT,
        "second_deployment":AZURE_OPENAI_SECOND_DEPLOYMENT, 
        "embedding_deployment" : AZURE_OPENAI_EMBEDDING_DEPLOYMENT , 
        "retry_count" : AZURE_OPENAI_RETRY_COUNT,
        "retry_interval" : AZURE_OPENAI_RETRY_INTERVAL,
        "chat_temperature" : AZURE_OPENAI_CHAT_TEMPERATURE,
        "system_prompt" : "あなたは生命保険会社の業務に関する質問に答えるヘルプデスクです。\n以下の条件に則りマークダウン形式で回答を生成してください。ただし、注釈は使用しないで下さい。\n\n###条件###\n・質問に対してなるべく引用情報のテキストを利用して回答を生成してください。\n・質問に関連する引用情報がない場合は、学習データをもとに回答してください。\n・引用情報から作成した回答には2個の※マークで引用した文書名の情報を囲って記載してください。\n  例えばinfo1.pdf (P1 - P2)という文書を基に「書面による確認や電話確認などを行うことができます。」という回答を生成した場合は、\n  書面による確認や電話確認などを行うことができます。※※info1.pdf (P1 - P2)※※のように回答してください。※※文書名：info1.pdf (P1 - P2)※※といった書き方はしないでください。\n・引用情報が複数ある場合、それぞれ分けて文書名を記載してください。\n  例えば※※info1.pdf (P3 - P4)※※,※※info2.pdf (P3 - P10)※※,※※info3.pdf (P80 - P100)※※ のように回答してください\n・回答には、回答文と引用した文書名を必ず記載してください。\n・info.pdfに類似する引用情報は使用しないでください。\n・あなたの回答は、全体で1400文字いないで回答できるようにまとめてください。",
        "prompt_template" : "",
        "output_max_token" : 1600,
        "first_model_approx_max_tokens": AZURE_OPENAI_FIRST_MODEL_APPROX_MAX_TOKENS,
        "second_model_approx_max_tokens": AZURE_OPENAI_SECOND_MODEL_APPROX_MAX_TOKENS
    }

}