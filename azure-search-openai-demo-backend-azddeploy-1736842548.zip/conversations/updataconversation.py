import json
import datetime
from azure.storage.blob import ContainerClient
from util.logger import create_debug_conversationlog_error, create_debug_conversationlog_info

def updateConversationBlob(blob_container:ContainerClient, conversation, env:str) -> str:
    try:
        # JSONデータを文字列に変換
        json_string = json.dumps(conversation)
        # "yyyy/mm/dd HH:MM:ss" → "yyyymmdd_HHMMss"形式の文字列に変換
        formatted_datetime = conversation["conversation_timestamp"].replace('/', '').replace(' ', '_').replace(':', '')
        # Blobにアップロードにするファイル名
        blob_name = conversation["userid"] + "/" + conversation["tenant"] + "/conversation_" + formatted_datetime
        # Blobにアップロード
        blob_client = blob_container.get_blob_client(blob_name)
        blob_client.upload_blob(json_string, overwrite=True)
        # log出力
        create_debug_conversationlog_info(env, "upload", conversation)
        return conversation
    except Exception as e:
        create_debug_conversationlog_error(env, "upload", conversation, "Upload failed. (update)")


def addConversationBlob(blob_container:ContainerClient, conversation, env:str) -> str:
    try:
        # 現在の年月日時分秒を取得
        now = datetime.datetime.now()
        # "yyyymmdd_HHMMss"形式の文字列に変換
        formatted_datetime = now.strftime("%Y%m%d_%H%M%S")
        # Blobにアップロードにするファイル名
        blob_name = conversation["userid"] + "/" + conversation["tenant"] + "/conversation_" + formatted_datetime
        # "yyyy/mm/dd HH:MM:ss"形式の文字列に変換
        conversation_timestamp = now.strftime("%Y/%m/%d %H:%M:%S")
        # jsonに付与するタイムスタンプ格納
        conversation["conversation_timestamp"] = conversation_timestamp
        # JSONデータを文字列に変換
        json_string = json.dumps(conversation)
        # Blobにアップロード
        blob_client = blob_container.get_blob_client(blob_name)
        blob_client.upload_blob(json_string, overwrite=True)
        # log出力
        create_debug_conversationlog_info(env, "upload", conversation)
        return conversation
    except Exception as e:
        create_debug_conversationlog_error(env, "upload", conversation, "Upload failed. (add)")


def uploadConversationBlob(blob_container:ContainerClient, conversation, env:str) -> str:
    if "conversation_timestamp" in conversation and conversation["conversation_timestamp"]:
        return updateConversationBlob(blob_container, conversation, env)
    else:
        return addConversationBlob(blob_container, conversation, env)
