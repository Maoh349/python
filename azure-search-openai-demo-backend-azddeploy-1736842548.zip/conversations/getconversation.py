import json
from azure.storage.blob import ContainerClient
from util.logger import create_debug_conversationlog_error

def getAllRelatedBlob(blob_container:ContainerClient, userid:str, tenant:str):
    blob_list = blob_container.list_blobs(name_starts_with=f"{userid}/{tenant}")
    return (blob_list)

def retrieveUserConversation(blob_container:ContainerClient, userid:str, tenant:str, env:str):
    try:
        blob_list = getAllRelatedBlob(blob_container,userid,tenant)
        # 各Blobからデータを取得し、マージ
        history_list=[]
        for blob in blob_list:
            blob_client = blob_container.get_blob_client(blob.name)
            blob_data = blob_client.download_blob().readall()
            json_data = json.loads(blob_data)
            history_list.append(json_data)
        # タイムスタンプを降順でソート
        sorted_history_list = sorted(history_list, key=lambda x: x['conversation_timestamp'], reverse = True)
        return {"conversations": sorted_history_list}
    except Exception as e:
        conversation = { tenant: tenant, userid: userid }
        create_debug_conversationlog_error(env, "get", conversation, "Get failed.")
