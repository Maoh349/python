import copy
import os
import concurrent.futures
import datetime
import json
import openai
import time
from openai import AzureOpenAI
import openai
from fileupload.fileuploadprompt import message_type, template_message
from config import config_list
from util.logger import get_chat_fileUpload_messages_as_text, create_debug_querylog_error,handle_autoPrompt_success_log,handle_image_autoPrompt_success_log,handle_image_userPrompt_success_log
from util.getencodingmodel import get_encoding_model
from fileupload.fileuploadprompt import message_type, template_message,image_message_type,image_userprompt_message
AZURE_OPENAI_FIRST_MODEL_APPROX_MAX_TOKENS = int(os.environ.get("AZURE_OPENAI_FIRST_MODEL_APPROX_MAX_TOKENS") or "1000")
AZURE_OPENAI_SECOND_MODEL_APPROX_MAX_TOKENS = int(os.environ.get("AZURE_OPENAI_SECOND_MODEL_APPROX_MAX_TOKENS") or "20000")

class fileUploadChat:

    def __init__(self, model_name: str, openai_client: AzureOpenAI, approach:str, fileNames:list, chunk:str,base64Images:list, history:str, tenant:str, overrides:str, env:str):
        self.model_name = model_name
        self.openai_client = openai_client
        self.approach = approach
        self.fileNames = fileNames
        self.chunk = chunk
        self.base64Images = base64Images
        self.history = history
        self.tenant = tenant
        self.overrides = overrides
        self.env = env
    
    def create_message_list(self, prompt, chunk, type=False, chunk_N_modifier=lambda x: x):
        message_list = []
        chunk_N = len(chunk)
        if type == False:
            if len(self.history)>1: #更問時
                for chunk_i in chunk:
                    message_list += template_message(prompt, chunk_i[0])
            else:
                for chunk_i in chunk:
                    message_list.append(template_message(prompt, chunk_i[0]))
        else:
            modified_chunk_N = chunk_N_modifier(chunk_N)
            for chunk_i in chunk:
                message = message_type(prompt, chunk_i[0], modified_chunk_N)
                message_list.append(message)
        return message_list

    def process_messages(self, auto_prompt, message_list, chunk_N_modifier=lambda x: 0):
        chunk_N = len(self.chunk)
        dt = datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S")
        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
                chat_answer_para = executor.map(self.chat_model, message_list, dt, auto_prompt)

            result_list = [chat_answer.choices[0].message.content.strip() for chat_answer in chat_answer_para]

            if chunk_N_modifier(chunk_N) != 0:
                mix_message = message_type(auto_prompt, ''.join(result_list), 1)
                final_answer = self.chat_model(mix_message, dt, auto_prompt).choices[0].message.content.strip()
                result_list = [final_answer]

            result = {
                "data_points": "", 
                "answer": "\n".join(result_list), 
                "thoughts": ""
            }

            # ログ出力
            prompt = get_chat_fileUpload_messages_as_text(message_list, "\n".join(result_list))
            additional_args = {
                    "model_name": self.model_name,
            }
            if auto_prompt in [0,1,2,3,4]:
                additional_args["auto_prompt"] = auto_prompt
            handle_autoPrompt_success_log(dt, self.env, self.history[-1]["user"], self.overrides, self.history[-1]["user"], prompt, self.approach,config_list[self.approach]["chat_temperature"], self.tenant, **additional_args)
            
            return result
        except Exception as e:
            error_json_data = {"error": str(e)}
            return error_json_data
    
    def add_question(self, message_list:list, used_chars:str):
        dt = datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S")
        if len( get_encoding_model(self.model_name).encode(used_chars) ) > AZURE_OPENAI_FIRST_MODEL_APPROX_MAX_TOKENS*4:
            return 
        history = self.history[:len(self.history)-1]
        try:
            for chat in reversed(history):
                used_chars += chat['user'] + chat['bot']
                if len( get_encoding_model(self.model_name).encode(used_chars) ) > AZURE_OPENAI_FIRST_MODEL_APPROX_MAX_TOKENS*4:
                    break
                user_chat = {
                    "role":"user",
                    "content":chat['user']
                }
                message_list.insert(1, user_chat)
                assistant_chat = {
                    "role":"assistant",
                    "content":chat['bot']
                }
                message_list.insert(2, assistant_chat)
            answer = self.chat_model(message_list, dt)
            answer = answer.choices[0].message.content
            result = {
                    "data_points": "", 
                    "answer": answer, 
                    "thoughts": ""
                }
            prompt = get_chat_fileUpload_messages_as_text(message_list, answer)
            additional_args = {
                    "model_name": self.model_name,
            }
            handle_autoPrompt_success_log(dt, self.env, self.history[-1]["user"], self.overrides, self.history[-1]["user"], prompt, self.approach,config_list[self.approach]["chat_temperature"], self.tenant, **additional_args)
            return result
        except Exception as e:
            error_json_data = {"error": str(e)}
            return error_json_data

    def template_process(self):
        if len(self.history) > 1:   #更問時の処理
            prompt = self.history[-1]["user"]
            message_list = self.create_message_list(prompt, self.chunk)
            used_chars = message_list[0]["content"]
            used_chars += prompt
            result = self.add_question(message_list,used_chars)
            return result       
        else:
            prompt = self.history[0]["user"]
            message_list = self.create_message_list(prompt, self.chunk)
            return self.process_messages(
                self.history[0]["user"],
                message_list
            )

    def mix_process(self, auto_prompt):
        message_list = self.create_message_list(auto_prompt, self.chunk, type=True, chunk_N_modifier=lambda x: x)
        return self.process_messages(
            auto_prompt,
            message_list,
            chunk_N_modifier=lambda x: x
        )

    def join_process(self, auto_prompt):
        message_list = self.create_message_list(auto_prompt, self.chunk, type=True, chunk_N_modifier=lambda x: 0)
        return self.process_messages(
            auto_prompt,
            message_list
        )

    def chat_model(self, message:str, dt:str, auto_prompt:int=None):
        error_params = {
            "search":self.history[-1]["user"].replace('\n', '<br>'),
            "prompt":get_chat_fileUpload_messages_as_text(message, "").replace('\n', '<br>'),
            "engine":self.model_name,
        }
        if auto_prompt in [0,1,2,3,4]:
            error_params["auto_prompt"] = auto_prompt

        retry_count = config_list[self.approach]["retry_count"]
        retry_interval = config_list[self.approach]["retry_interval"]
        for count in range( retry_count ):
            try:
                max_tokens = config_list[self.approach]["output_max_token"]
                chatCompletion = self.openai_client.chat.completions.create(
                    model=self.model_name,
                    messages = message,#[{"role":"user", "content": prompt}],#文脈を生成するためのメッセージ
                    temperature= config_list[self.approach]["chat_temperature"], #生成される文章に含む単語の出現確立（0～1 1だと多様な文章、0だと一定の傾向をもった文章）
                    max_tokens=max_tokens,  # 生成されるレスポンスのトークンの最大数
                    n=1, #回答の数。3を指定すれば3つの回答を得られる。
                    stop=None, #トークンの生成を停止する文字列
                    timeout=100)
            except openai.BadRequestError as e:
                error_params["answer"] = f"OpenAI api で {e.code} Error 発生"
                create_debug_querylog_error(dt, self.env, self.history[-1]["user"], self.overrides, self.approach, self.tenant, **error_params)
                if e.code == "context_length_exceeded":
                    raise Exception("プロンプトの文字数を減らしてください")
                else:
                    raise Exception("プロンプトを修正してください") # invalid_prompt
            except openai.APITimeoutError as e:
                error_params["answer"] = f"OpenAI api でTimeOut発生"
                create_debug_querylog_error(dt, self.env, self.history[-1]["user"], self.overrides, self.approach, self.tenant, **error_params)
                raise Exception("タイムアウトが発生しました")
            except Exception as e:
                error_params["answer"] = f"OpenAI api でエラー発生"
                if count:
                    error_params["retry"] = f"{count + 1}/{retry_count} (Interval:{retry_interval}sec)"

                create_debug_querylog_error(dt, self.env, self.history[-1]["user"], self.overrides, self.approach, self.tenant, **error_params)      
                if count + 1 >= retry_count :
                    raise Exception("OpenAI APIでエラーが発生しました")
                else:
                    time.sleep( retry_interval )
            else:
                break
        else:
            raise Exception(f"OpenAI APIでエラーが発生しました")
        
        return chatCompletion
    #-------GPT-4o以降用
    def create_answer(self, message:list, prompt:str, dt:str, fileNames:list, auto_prompt:int=None):
        error_params = {
            "search":self.history[-1]["user"].replace('\n', '<br>'),
            "prompt":prompt,
            "engine":self.model_name,
            "filename":fileNames,
        }
        if auto_prompt in [0,1,2,3,4]:
            error_params["auto_prompt"] = auto_prompt
        
        retry_count = config_list[self.approach]["retry_count"]
        retry_interval = config_list[self.approach]["retry_interval"]
        for count in range( retry_count ):

            try:
                chatCompletion = self.openai_client.chat.completions.create(
                    model=self.model_name,
                    messages = message, #[{"role":"user", "content": prompt}],#文脈を生成するためのメッセージ
                    temperature= config_list[self.approach]["chat_temperature"], #生成される文章に含む単語の出現確立（0～1 1だと多様な文章、0だと一定の傾向をもった文章）
                    max_tokens=None,  # 生成されるレスポンスのトークンの最大数
                    n=1, #回答の数。3を指定すれば3つの回答を得られる。
                    stop=None, #トークンの生成を停止する文字列
                    stream=True,
                    timeout=180)
            except openai.BadRequestError as e:
                error_params["answer"] = f"OpenAI api で {e.code} Error 発生"
                create_debug_querylog_error(dt, self.env, self.history[-1]["user"], self.overrides, self.approach, self.tenant, **error_params)
                if e.code == "context_length_exceeded":
                    raise Exception("プロンプトの文字数を減らしてください")
                else:
                    raise Exception("プロンプトを修正してください") # invalid_prompt
            except openai.APITimeoutError as e:
                error_params["answer"] = f"OpenAI api でTimeOut発生"
                create_debug_querylog_error(dt, self.env, self.history[-1]["user"], self.overrides, self.approach, self.tenant, **error_params)
                raise Exception("タイムアウトが発生しました")
            
            except Exception as e:
                error_params["answer"] = f"OpenAI api でエラー発生"
                if count:
                    error_params["retry"] = f"{count + 1}/{retry_count} (Interval:{retry_interval}sec)"
                create_debug_querylog_error(dt, self.env, self.history[-1]["user"], self.overrides, self.approach, self.tenant, **error_params)      
                
                if count + 1 >= retry_count :
                    raise Exception("OpenAI APIでエラーが発生しました")
                else:
                    time.sleep( retry_interval )
            else:
                break
        else:
            raise Exception(f"OpenAI APIでエラーが発生しました")
        
        return chatCompletion

    def answer_by_autoprompt(self, auto_prompt:int):
        dt = datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S")
        #autopromptに応じてmessage作成
        message = image_message_type(auto_prompt,self.base64Images)
        #ログ用のprompt処理
        prompt = copy.deepcopy(message)
        new_content = [item for item in prompt[-1]["content"] if item.get("type") != "image_url"]   #画像のbase64コードを除外
        prompt[-1]["content"] = new_content
        try: 
            # 回答生成
            answer = self.create_answer(message, prompt, dt, self.fileNames, auto_prompt)
            marge_answer = ""
            for event in answer:
                if not len(event.choices):
                    continue
                else:
                    for choice in event.choices:
                        if choice.delta and choice.finish_reason is None:
                            content = choice.delta.content
                            json_data = json.dumps({"content": content})
                            marge_answer += content
                            yield f"{json_data}\n"
            #ログ用の処理
            additional_args = {
                    "model_name": self.model_name,
            }
            if auto_prompt in [0,1,2,3,4]:
                additional_args["auto_prompt"] = auto_prompt
            handle_image_autoPrompt_success_log(dt, self.env, self.history[-1]["user"], self.overrides, self.history[-1]["user"], self.fileNames, prompt,marge_answer, self.approach,config_list[self.approach]["chat_temperature"], self.tenant, **additional_args)
        except Exception as e:
            error_json_data = {"error": str(e)}
            yield json.dumps(error_json_data)

    #自由入力の時の回答生成関数
    def answer_by_userprompt(self):
        dt = datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S")
        #ユーザープロンプト
        prompt=self.history[-1]["user"]
        #AIに渡すmessageの作成
        message = image_userprompt_message(prompt,self.base64Images)
        #更問時の処理
        used_chars = message[0]["content"]
        used_chars += prompt
        if len( get_encoding_model(self.model_name).encode(used_chars) ) > AZURE_OPENAI_SECOND_MODEL_APPROX_MAX_TOKENS*4:
            return message
        history = self.history[:len(self.history)-1]
        for chat in reversed(history):
            used_chars += chat['user'] + chat['bot']
            if len( get_encoding_model(self.model_name).encode(used_chars) ) > AZURE_OPENAI_SECOND_MODEL_APPROX_MAX_TOKENS*4:
                break
            user_chat = {
                "role":"user",
                "content":chat['user']
            }
            message.insert(1, user_chat)
            assistant_chat = {
                "role":"assistant",
                "content":chat['bot']
            }
            message.insert(2, assistant_chat)

        #ログ用のprompt処理
        log_prompt = copy.deepcopy(message)
        new_content = [item for item in log_prompt[-1]["content"] if item.get("type") != "image_url"]   #画像のbase64コードを除外
        log_prompt[-1]["content"] = new_content
        try:
            #回答生成
            answer = self.create_answer(message, log_prompt, dt, self.fileNames)
            marge_answer = ""
            for event in answer:
                if not len(event.choices):
                    continue
                else:
                    for choice in event.choices:
                        if choice.delta and choice.finish_reason is None:
                            content = choice.delta.content
                            json_data = json.dumps({"content": content})
                            marge_answer += content
                            yield f"{json_data}\n"

            #ログ用の処理
            additional_args = {
                    "model_name": self.model_name,
            }
            handle_image_userPrompt_success_log(dt, self.env, self.history[-1]["user"], self.overrides, self.history[-1]["user"], self.fileNames, prompt, marge_answer, self.approach,config_list[self.approach]["chat_temperature"], self.tenant, **additional_args)
        except Exception as e:
            error_json_data = {"error": str(e)}
            yield json.dumps(error_json_data)

