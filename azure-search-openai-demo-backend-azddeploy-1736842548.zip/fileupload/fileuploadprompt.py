def template_message(usersetting_condition, target_text):
    system_prompt =  """
    あなたはユーザを補助するシステムです。
    ユーザの会話に基づいて適切な回答を生成してください。
    マークダウン形式で回答を生成してください。ただし、注釈は使用しないで下さい。

    """
    messages = [
        { 
            "role":"system",
            "content":system_prompt
        }
    ]

    user_prompt =""" 
    {usersetting_condition}

    **入力文**:
    {target_text}

    <|im_end|>
    <|im_start|>assistant

    """.format(usersetting_condition=usersetting_condition, target_text=target_text)

    messages.append(
            {
                "role":"user",
                "content": user_prompt #システムプロンプトのFew Shotに準ずる形にする
            }
        ) 

    return messages





def message_type(auto_prompt, target_text, chunk_N):
    if(auto_prompt==1):
        return summary_message(target_text, chunk_N)#要約
    elif(auto_prompt==3):
        return taransfer_jte_messages(target_text)#英語への翻訳
    elif(auto_prompt==4):
        return taransfer_etj_messages(target_text)#日本語への翻訳
    elif(auto_prompt==0):
        return proofreading_prompt(target_text)#文章の校正
    elif(auto_prompt==2):
        return minutes_prompt(target_text)#議事録の作成
    



def summary_message(target_text, chunk_N):


    system_prompt =  """
    あなたは文章要約をしたいユーザを補助するシステムです。
    ユーザが入力した文章の要約会話に基づいて要約をします。
    以下の条件に則りマークダウン形式で回答を生成してください。ただし、注釈は使用しないで下さい。
    """

    messages = [
        { 
            "role":"system",
            "content":system_prompt
        }
    ]
    max_sententh_length = 5000/chunk_N
    user_prompt =""" 
    **条件**:
    - あなたは編集を担当しているビジネスマンです。
    - 入力文の中の「#」や「<>」などの記号は除いて要約してください。
    - 入力文の中の重要なキーワードは要約する時に利用してください。
    - 入力文の中の数字は変更せず利用してください。
    - 要約はなるべく詳しく書いてください
    - 要約は必ず{max_sententh_length}文字以内にしてください。
    - 入力文を使って要約した文章だけを結果として表示してください
    - 冒頭、文末のあいさつは不要です。
    - 見出しを適切に使用して、内容を整理する
    - 箇条書きや番号付きリストを使用する
    - 強調したい部分は太字にする

    **入力文**:
    {target_text}

    <|im_end|>
    <|im_start|>assistant

    """.format(target_text=target_text, max_sententh_length=max_sententh_length)
    messages.append(
            {
                "role":"user",
                "content": user_prompt #システムプロンプトのFew Shotに準ずる形にする
            }
        ) 

    return messages

def taransfer_etj_messages(target_text) :#英語を日本語に翻訳するためのプロンプト
 
    system_prompt =  """
    あなたは文章翻訳をしようとしているユーザを補助するシステムです。
    ユーザの会話に基づいて翻訳をします。
    以下の条件に則りマークダウン形式で回答を生成してください。ただし、注釈は使用しないで下さい。
    """
    messages = [
        { 
            "role":"system",
            "content":system_prompt
        }
    ]

    user_prompt = """
    ・あなたは翻訳家です。
    ・下記条件に従って入力文を日本語に翻訳してください。
 
    **条件**:
    - 平易な日本語で表現

    **入力文**:
    {target_text}

    <|im_end|>
    <|im_start|>assistant

    """.format(target_text=target_text)

    messages.append(
            {
                "role":"user",
                "content": user_prompt #システムプロンプトのFew Shotに準ずる形にする
            }
        ) 

    return messages

def taransfer_jte_messages(target_text) :#日本語を英語に翻訳するためのプロンプト
 
    system_prompt =  """
    あなたは文章翻訳をしようとしているユーザを補助するシステムです。
    ユーザの会話に基づいて翻訳をします。
    以下の条件に則りマークダウン形式で回答を生成してください。ただし、注釈は使用しないで下さい。
    """
    messages = [
        { 
            "role":"system",
            "content":system_prompt
        }
    ]

    user_prompt = """
    ・あなたは翻訳家です。
    ・下記条件に従って入力文を英語に翻訳してください。
 
    **条件**:
    - 平易な英語で表現

    **入力文**:
    {target_text}

    <|im_end|>
    <|im_start|>assistant

    """.format(target_text=target_text)

    messages.append(
            {
                "role":"user",
                "content": user_prompt #システムプロンプトのFew Shotに準ずる形にする
            }
        ) 

    return messages


def proofreading_prompt(target_text) :#文章の校正修正するためのプロンプト
 
    system_prompt =  """
    あなたは文章添削をしようとしているユーザを補助するシステムです。
    下記条件に一致する場合は添削を実施するのが仕事です
    ・添削はビジネスの場にふさわしくない言葉遣い
    ・明らかに言い間違いや誤字脱字
    以下の条件に則りマークダウン形式で回答を生成してください。ただし、注釈は使用しないで下さい。
    """
    messages = [
        { 
            "role":"system",
            "content":system_prompt
        }
    ]

    user_prompt  =  """
    あなたは校正を担当しているビジネスマンです。
    出された命令には必ず従います
    下記条件に従って入力文の校正をしてください
    **条件**:
    - 入力文に対して3件校正結果を記載する
    - 校正する文章がない場合は結果を出力しない
    - 校正結果を表示する前に必ず添削の前後で文章が変わっているか確認してください。もし校正の前後で文書が変わっていなければ表示しないでください
    - 校正結果に対して修正前の文章、修正後の文章の両方を出力する
    - 校正結果の出力は###出力例を参考にしてください
    - 校正結果を出力する前に###出力してはいけない結果が含まれていないか確認してください。###出力してはいけない結果が含まれている場合、該当の結果を除いて校正結果を出力してください
    - 見出しを適切に使用して、内容を整理する
    - 箇条書きや番号付きリストを使用する
    - 強調したい部分は太字にする
    
    ###出力してはいけない結果
    添削
    ・修正前: 
    ・修正後: 
    添削
    ・修正前: 
    ・修正後:

    ###出力例
    添削
    ・修正前: 今日の会議では来年度の予算について議論しましtった
    ・修正後: 本日の会議では来年度の予算について議論しました
    添削
    ・修正前: 共有頂いた資料を角煮にします
    ・修正後: 共有頂いた資料を確認します
    添削
    ・修正前: 自身の誤ちを認める
    ・修正後: 自身の過ちを認める


    **入力文**:
    {target_text}

    <|im_end|>
    <|im_start|>assistant

    """.format(target_text=target_text)

    messages.append(
            {
                "role":"user",
                "content": user_prompt #システムプロンプトのFew Shotに準ずる形にする
            }
        ) 

    return messages

def minutes_prompt(target_text) :#文章の校正修正するためのプロンプト
 
    system_prompt =  """
    あなたは議事録をしようとしているユーザを補助するシステムです。
    ユーザの会話を基に議事録を作成してください。
    以下の条件に則りマークダウン形式で回答を生成してください。ただし、注釈は使用しないで下さい。

    **回答形式**:
    発言者：発言内容


    **例**:
    田中：新規チャットを押してもまだ履歴には出てこないです。
    田中：本機能は2024年5月の実装を目指しています。
    山田：チャットを実行すると常に履歴内容が更新されるようにする予定です

    """
    messages = [
        { 
            "role":"system",
            "content":system_prompt
        }
    ]

    user_prompt  =  """
    **指示**:
    - あなたは校正の担当者です。
    以下の「議事メモ」は会議内容の文字起こしです。
    「制約条件」に従い、日本語のブラッシュアップをしてください。


    **制約条件**:
    - 「あの」などのフィラーを削除、または適正化すること
    - 誤字脱字を修正すること
    - 句読点を正しい位置に修正すること
    - 発言者を記載すること（不明であれば仮称を設定）
    - 結果の作成後、再度プロンプトに合っているか再検討すること
    - 見出しを適切に使用して、内容を整理する

    **議事メモ**:
    {target_text}

    <|im_end|>
    <|im_start|>assistant

    """.format(target_text=target_text)
    messages.append(
            {
                "role":"user",
                "content": user_prompt #システムプロンプトのFew Shotに準ずる形にする
            }
        ) 

    return messages

#-----GPT-4o対応
def image_message_type(auto_prompt,base64_image_list):
    if(auto_prompt==0):
        return image_proofreading_prompt(base64_image_list)#文章の校正
    elif(auto_prompt==1):
        return image_summary_message(base64_image_list)#要約
    elif(auto_prompt==2):
        return image_minutes_prompt(base64_image_list)#議事録の作成
    elif(auto_prompt==3):
        return image_taransfer_jte_messages(base64_image_list)#英語への翻訳
    elif(auto_prompt==4):
        return image_taransfer_etj_messages(base64_image_list)#日本語への翻訳

#system prompt,user prompt,画像情報を元にmessageを作成する関数
def create_user_content(system_prompt,user_prompt,base64_image_list):
    messages = [
        { 
            "role":"system",
            "content":system_prompt
        }
    ]

    user_content = [{"type":"text","text":user_prompt}]\
                    +[{"type": "image_url", "image_url": {"url": f"data:image/png;base64,{base64_image}"}} for base64_image in base64_image_list]

    messages.append(
            {
                "role":"user",
                "content": user_content
            }
        ) 
    return messages

#文章の校正修正するためのプロンプト(autoprompt = 0)
def image_proofreading_prompt(base64_image_list) :
    system_prompt =  """
    あなたは文章添削をしようとしているユーザを補助するシステムです。
    下記条件に一致する場合は添削を実施するのが仕事です
    ・添削はビジネスの場にふさわしくない言葉遣い
    ・明らかに言い間違いや誤字脱字
    以下の条件に則りマークダウン形式で回答を生成してください。ただし、注釈は使用しないで下さい。
    """
    user_prompt  =  """
    あなたは校正を担当しているビジネスマンです。
    出された命令には必ず従います
    下記条件に従って校正をしてください
    **条件**:
    - 入力文に対して3件校正結果を記載する
    - 校正する文章がない場合は結果を出力しない
    - 校正結果を表示する前に必ず添削の前後で文章が変わっているか確認してください。もし校正の前後で文書が変わっていなければ表示しないでください
    - 校正結果に対して修正前の文章、修正後の文章の両方を出力する
    - 校正結果の出力は###出力例を参考にしてください
    - 校正結果を出力する前に###出力してはいけない結果が含まれていないか確認してください。###出力してはいけない結果が含まれている場合、該当の結果を除いて校正結果を出力してください
    
    **出力してはいけない結果**:
    添削
    ・修正前: 
    ・修正後: 
    添削
    ・修正前: 
    ・修正後:

    **出力例**:
    添削
    ・修正前: 今日の会議では来年度の予算について議論しましtった
    ・修正後: 本日の会議では来年度の予算について議論しました
    添削
    ・修正前: 共有頂いた資料を角煮にします
    ・修正後: 共有頂いた資料を確認します
    添削
    ・修正前: 自身の誤ちを認める
    ・修正後: 自身の過ちを認める
    """
    
    messages = create_user_content(system_prompt,user_prompt,base64_image_list)

    return messages

#要約のプロンプト(autoprompt = 1)
def image_summary_message(base64_image_list):
    system_prompt =  """
    あなたは文章要約をしたいユーザを補助するシステムです。
    ユーザがアップロードした画像の内容を要約をします。
    以下の条件に則りマークダウン形式で回答を生成してください。ただし、注釈は使用しないで下さい。
    """

    user_prompt =""" 
    **条件**:
    - あなたは編集を担当しているビジネスマンです。
    - 画像の内容をなるべく詳しく要約してください。
    - 重要なキーワードは要約する時に利用してください。
    - 数字は変更せず利用してください。
    - 要約した文章だけを結果として表示してください。
    - 冒頭、文末のあいさつは不要です。
    """

    messages = create_user_content(system_prompt,user_prompt,base64_image_list) 

    return messages

#議事録作成のプロンプト(autoprompt = 2)
def image_minutes_prompt(base64_image_list) :
    system_prompt =  """
    あなたは議事録をしようとしているユーザを補助するシステムです。
    ユーザの会話を基に例のような議事録を作成してください。
    以下の条件に則りマークダウン形式で回答を生成してください。ただし、注釈は使用しないで下さい。
    """

    user_prompt  =  """
    **指示**:
    - あなたは校正の担当者です。
    - 「制約条件」に従い、日本語のブラッシュアップをしてください。

    **制約条件**:
    - 「あの」などのフィラーを削除、または適正化すること
    - 誤字脱字を修正すること
    - 句読点を正しい位置に修正すること
    - 発言者を記載すること（不明であれば仮称を設定）
    - 結果の作成後、再度プロンプトに合っているか再検討すること

    **回答形式**:
    発言者：発言内容

    **例**:
    田中：新規チャットを押してもまだ履歴には出てこないです。
    田中：本機能は2024年5月の実装を目指しています。
    山田：チャットを実行すると常に履歴内容が更新されるようにする予定です
    """

    messages = create_user_content(system_prompt,user_prompt,base64_image_list)

    return messages

#日本語を英語に翻訳するためのプロンプト(autoprompt = 3)
def image_taransfer_jte_messages(base64_image_list) :
    system_prompt =  """
    あなたは文章翻訳をしようとしているユーザを補助するシステムです。
    ユーザの会話に基づいて翻訳をします。
    以下の条件に則りマークダウン形式で回答を生成してください。ただし、注釈は使用しないで下さい。
    """
    user_prompt = """
    ・あなたは翻訳家です。
    ・下記条件に従って英語に翻訳してください。
 
    **条件**:
    - 平易な英語で表現
    """

    messages = create_user_content(system_prompt,user_prompt,base64_image_list)

    return messages

#英語を日本語に翻訳するためのプロンプト(autoprompt = 4)
def image_taransfer_etj_messages(base64_image_list) :
    system_prompt =  """
    あなたは文章翻訳をしようとしているユーザを補助するシステムです。
    ユーザの会話に基づいて翻訳をします。
    以下の条件に則りマークダウン形式で回答を生成してください。ただし、注釈は使用しないで下さい。
    """
    user_prompt = """
    ・あなたは翻訳家です。
    ・下記条件に従って日本語に翻訳してください。
 
    **条件**:
    - 平易な日本語で表現
    """

    messages = create_user_content(system_prompt,user_prompt,base64_image_list)

    return messages

#自由入力の場合のプロンプト
def image_userprompt_message(usersetting_condition,base64_image_list):
    system_prompt =  """
    あなたはユーザを補助するシステムです。
    ユーザの会話に基づいて適切な回答を生成してください。
    マークダウン形式で回答を生成してください。ただし、注釈は使用しないで下さい。
    """

    user_prompt =""" 
    {usersetting_condition}

    """.format(usersetting_condition=usersetting_condition)

    messages = create_user_content(system_prompt,user_prompt,base64_image_list)

    return messages

#-----GPT-4o以降のテキスト時
def text_message_type(auto_prompt, target_text):
    if(auto_prompt==0):
        return text_proofreading_prompt(target_text)#文章の校正
    elif(auto_prompt==1):
        return text_summary_message(target_text)#要約
    elif(auto_prompt==2):
        return text_minutes_prompt(target_text)#議事録の作成
    elif(auto_prompt==3):
        return text_taransfer_jte_messages(target_text)#英語への翻訳
    elif(auto_prompt==4):
        return text_taransfer_etj_messages(target_text)#日本語への翻訳


#文章の校正修正するためのプロンプト(autoprompt = 0)
def text_proofreading_prompt(target_text) :#文章の校正修正するためのプロンプト
    system_prompt =  """
    あなたは文章添削をしようとしているユーザを補助するシステムです。
    下記条件に一致する場合は添削を実施するのが仕事です
    ・添削はビジネスの場にふさわしくない言葉遣い
    ・明らかに言い間違いや誤字脱字
    以下の条件に則りマークダウン形式で回答を生成してください。ただし、注釈は使用しないで下さい。
    """
    messages = [
        { 
            "role":"system",
            "content":system_prompt
        }
    ]

    user_prompt  =  """
    あなたは校正を担当しているビジネスマンです。
    出された命令には必ず従います
    下記条件に従って入力文の校正をしてください
    **条件**:
    - 入力文に対して3件校正結果を記載する
    - 校正する文章がない場合は結果を出力しない
    - 校正結果を表示する前に必ず添削の前後で文章が変わっているか確認してください。もし校正の前後で文書が変わっていなければ表示しないでください
    - 校正結果に対して修正前の文章、修正後の文章の両方を出力する
    - 校正結果の出力は###出力例を参考にしてください
    - 校正結果を出力する前に###出力してはいけない結果が含まれていないか確認してください。###出力してはいけない結果が含まれている場合、該当の結果を除いて校正結果を出力してください
    
    **出力してはいけない結果**:
    添削
    ・修正前: 
    ・修正後: 
    添削
    ・修正前: 
    ・修正後:

    **出力例**:
    添削
    ・修正前: 今日の会議では来年度の予算について議論しましtった
    ・修正後: 本日の会議では来年度の予算について議論しました
    添削
    ・修正前: 共有頂いた資料を角煮にします
    ・修正後: 共有頂いた資料を確認します
    添削
    ・修正前: 自身の誤ちを認める
    ・修正後: 自身の過ちを認める


    **入力文**:
    {target_text}

    <|im_end|>
    <|im_start|>assistant

    """.format(target_text=target_text)

    messages.append(
            {
                "role":"user",
                "content": user_prompt #システムプロンプトのFew Shotに準ずる形にする
            }
        ) 

    return messages

#要約のプロンプト(autoprompt = 1)
def text_summary_message(target_text):
    system_prompt =  """
    あなたは文章要約をしたいユーザを補助するシステムです。
    ユーザが入力した文章の要約会話に基づいて要約をします。
    以下の条件に則りマークダウン形式で回答を生成してください。ただし、注釈は使用しないで下さい。
    """

    messages = [
        { 
            "role":"system",
            "content":system_prompt
        }
    ]
    user_prompt =""" 
    **条件**:
    - あなたは編集を担当しているビジネスマンです。
    - ###入力文の中の「#」や「<>」などの記号は除いて要約してください。
    - ###入力文の中の重要なキーワードは要約する時に利用してください。
    - ###入力文の中の数字は変更せず利用してください。
    - 要約はなるべく詳しく書いてください
    - ###入力文を使って要約した文章だけを結果として表示してください
    - 冒頭、文末のあいさつは不要です。
    - 見出しを適切に使用して、内容を整理する
    - 箇条書きや番号付きリストを使用する

    ###入力文
    {target_text}

    <|im_end|>
    <|im_start|>assistant

    """.format(target_text=target_text)
    messages.append(
            {
                "role":"user",
                "content": user_prompt #システムプロンプトのFew Shotに準ずる形にする
            }
        ) 

    return messages

#議事録作成のプロンプト(autoprompt = 2)
def text_minutes_prompt(target_text) :
    system_prompt =  """
    あなたは議事録をしようとしているユーザを補助するシステムです。
    ユーザの会話を基に議事録を作成してください。
    以下の条件に則りマークダウン形式で回答を生成してください。ただし、注釈は使用しないで下さい。

    **回答形式**:
    発言者：発言内容


    **例**:
    田中：新規チャットを押してもまだ履歴には出てこないです。
    田中：本機能は2024年5月の実装を目指しています。
    山田：チャットを実行すると常に履歴内容が更新されるようにする予定です

    """
    messages = [
        { 
            "role":"system",
            "content":system_prompt
        }
    ]

    user_prompt  =  """
    **指示**:
    - あなたは校正の担当者です。
    - 以下の「議事メモ」は会議内容の文字起こしです。
    - 「制約条件」に従い、日本語のブラッシュアップをしてください。


    **制約条件**:
    - 「あの」などのフィラーを削除、または適正化すること
    - 誤字脱字を修正すること
    - 句読点を正しい位置に修正すること
    - 発言者を記載すること（不明であれば仮称を設定）
    - 結果の作成後、再度プロンプトに合っているか再検討すること

    **議事メモ**:
    {target_text}

    <|im_end|>
    <|im_start|>assistant

    """.format(target_text=target_text)
    messages.append(
            {
                "role":"user",
                "content": user_prompt #システムプロンプトのFew Shotに準ずる形にする
            }
        ) 

    return messages

#日本語を英語に翻訳するためのプロンプト(autoprompt = 3)
def text_taransfer_jte_messages(target_text) :#日本語を英語に翻訳するためのプロンプト
    system_prompt =  """
    あなたは文章翻訳をしようとしているユーザを補助するシステムです。
    ユーザの会話に基づいて翻訳をします。
    以下の条件に則りマークダウン形式で回答を生成してください。ただし、注釈は使用しないで下さい。
    """
    messages = [
        { 
            "role":"system",
            "content":system_prompt
        }
    ]

    user_prompt = """
    ・あなたは翻訳家です。
    ・下記条件に従って入力文を英語に翻訳してください。
 
    **条件**:
    - 平易な英語で表現

    **入力文**:
    {target_text}

    <|im_end|>
    <|im_start|>assistant

    """.format(target_text=target_text)

    messages.append(
            {
                "role":"user",
                "content": user_prompt #システムプロンプトのFew Shotに準ずる形にする
            }
        ) 

    return messages

#英語を日本語に翻訳するためのプロンプト(autoprompt = 4)
def text_taransfer_etj_messages(target_text) :#英語を日本語に翻訳するためのプロンプト
    system_prompt =  """
    あなたは文章翻訳をしようとしているユーザを補助するシステムです。
    ユーザの会話に基づいて翻訳をします。
    以下の条件に則りマークダウン形式で回答を生成してください。ただし、注釈は使用しないで下さい。
    """
    messages = [
        { 
            "role":"system",
            "content":system_prompt
        }
    ]

    user_prompt = """
    ・あなたは翻訳家です。
    ・下記条件に従って入力文を日本語に翻訳してください。
 
    **条件**:
    - 平易な日本語で表現

    **入力文**:
    {target_text}

    <|im_end|>
    <|im_start|>assistant

    """.format(target_text=target_text)

    messages.append(
            {
                "role":"user",
                "content": user_prompt #システムプロンプトのFew Shotに準ずる形にする
            }
        ) 

    return messages