import openai
import time
from util.text import nonewlines
from util.changequestioncompletion import create_chat_question
from util.logger import create_debug_querylog_error, get_chat_messages_as_text
from util.getencodingmodel import get_encoding_model
from openai import AzureOpenAI


system_keyword_prompt = """
    あなたは検索しようとしているユーザを補助するシステムです。
    ユーザの会話や質問に基づいて質問文を検索クエリに変換します。
    
    ###条件###
    ・出力は検索クエリのみとしてください。
    ・質問からキーワード単語を抽出してください。
    ・出力する単語は名詞化してください。
    ・検索クエリ以外の返信は不要です。
    ・出力形式は次の通りです。

    ###回答形式###
    キーワード1、キーワード2、キーワード3、キーワード4、キーワード5、キーワード6

    ###例###
    入力：徳川家康の武功を教えてください。
    出力：徳川家康、人物、武功、業績

    入力：保険の契約書をなくした場合の対応はどうしたらいいですか?
    出力：保険、契約書、なくした、対応

    入力：地震による火災で家が消失したときの支払いは火災保険に含まれますか?
    出力：地震保険、火災保険、補償内容、支払条件

    """
# ***加藤追記 定義ファイルでインスタンス化して渡したいのでクラス化
class CreateKeywordCompletion():
    def is_use_only_latest_history(self, approach: str) -> bool:
        """
        最新の質問のみを使用して検索キーワードを生成する利用方法の場合TRUEを返します。
        """
        return approach == "rbr"

    def create_chat_keyword_messages(self, history: list[dict], approach: str, encoding_model, approx_max_tokens, chatgpt_deployment):
        """
        キーワード生成用のmessageを作成

        openAIの回答はキーワード生成時に使用しない(正しいキーワードが抽出できない可能性があるため)
        ChatCompletionの使用上、role:aiassitantなしでrole:userを複数追加できないため、
        historyのuserの情報を、role:userにすべてまとめて入れる

        履歴の文字列を、ChatCompletionの引数の形式に変換する
        例
        history = [ { user:"約款について教えてください" , bot:"約款とは・・・"} , { user:"火災保険は?" } ] 
        ↓
        messages = [
            { "role" : "system" , "content" : "以下のインプットから～"} ,
            { "role" : "user" , "content" : "入力：約款について教えてください 火災保険は?"} 
        ]
        """
        messages = [
            { 
                "role":"system",
                "content":system_keyword_prompt
            }
        ]

        user_messages = history[-1]['user']
        if approach == "esg" and len(get_encoding_model(chatgpt_deployment).encode(user_messages) )> approx_max_tokens*4:
            tokens = get_encoding_model(chatgpt_deployment).encode(user_messages)
            user_messages = get_encoding_model(chatgpt_deployment).decode(tokens[:approx_max_tokens*4])
        if len(get_encoding_model(chatgpt_deployment).encode(user_messages) )> approx_max_tokens*4:
            raise Exception("プロンプトの文字数を減らしてください")
        if not self.is_use_only_latest_history(approach):
            used_chars = system_keyword_prompt + user_messages
            if len( encoding_model.encode(used_chars) ) > approx_max_tokens*4:
                return messages

            history = history[:len(history)-1]
            for chat in reversed(history):
                used_chars += chat['user']
                if len( encoding_model.encode(used_chars) ) > approx_max_tokens*4:
                    break

                user_messages += chat['user']

        messages.append(
            {
                "role":"user",
                "content": f"入力：{user_messages}\n出力：" #システムプロンプトのFew Shotに準ずる形にする
            }
        ) 
        return messages

    def handle_openai_error(self, instance, startTime:str, dt:str, tenant:str, approach:str, env:str, latestQuery:str, prompt:str, overrides:dict, answer:str, count):
        """
        エラーログを出力します。
        """
        
        step1elapsedTime=time.time() - startTime
        params = {
            "answer": answer,
            "prompt":prompt.replace('\n', '<br>'),
            "step1elapsedTime":step1elapsedTime,
        }

        if count:
            params["retry"] = f"{count + 1}/{instance.retry_count} (Interval:{instance.retry_interval}sec)"

        create_debug_querylog_error(dt, env, latestQuery, overrides, approach, tenant, **params)

    def create_search_keyword(self, instance, history: list[dict], overrides: dict, tenant:str, approach: str, env: str, dt, startTime, openai_client: AzureOpenAI) -> str: 
        """
        ユーザの質問から検索用のキーワードを生成します。
        検索用キーワードは、以下の後続処理に使用します。
        ・引用文献を検索
        ・更問キーワードを生成
        """
        encoding_model = get_encoding_model(instance.chatgpt_deployment)
        # ChatCompleationメソッド用のプロンプトを作る
        messages = self.create_chat_keyword_messages(history, approach, encoding_model, instance.approx_max_tokens, instance.chatgpt_deployment)
        # ログ出力用に文字列に変換する
        prompt = get_chat_messages_as_text(messages,instance.approx_max_tokens)
        isChangeQuestion = False
        for count in range( instance.retry_count ):

            try:
                # ユーザの質問でキーワードの生成ができなかった場合、ユーザの質問を言い換える
                if isChangeQuestion:
                    questionCompletion = create_chat_question(history[-1]['user'], instance.chatgpt_deployment, openai_client)
                    if not "content" in questionCompletion.choices[0].message:
                        break
                    history[-1]['user'] = questionCompletion.choices[0].message.content.strip()
                    messages = self.create_chat_keyword_messages(history, approach)
                    prompt = get_chat_messages_as_text(messages,instance.approx_max_tokens)

                # 検索キーワードの生成
                chatCompletion = openai_client.chat.completions.create(
                    model=instance.chatgpt_deployment,
                    messages = messages,
                    temperature=0, 
                    max_tokens=100, 
                    n=1, 
                    stop=None,
                    timeout=60)

            except openai.BadRequestError as e:
                answer = f"Step1 OpenAI api で {e.code} Error発生"
                ####加藤追記＿count追加
                self.handle_openai_error(instance, startTime, dt, tenant, approach, env, history[-1]['user'], prompt, overrides, answer, count)
                if e.code == "context_length_exceeded":
                    raise Exception("プロンプトの文字数を減らしてください")
                else:
                    raise Exception("プロンプトを修正してください") # invalid_prompt
            except openai.APITimeoutError as e:
                answer = f"Step1 OpenAI api でTimeOut発生"
                self.handle_openai_error(instance, startTime, dt, tenant, approach, env, history[-1]['user'], prompt, overrides, answer, count)
                raise Exception("タイムアウトが発生しました")

            except Exception as e:
                answer = "step1 openAI apiで例外発生"
                self.handle_openai_error(instance, startTime, dt, tenant, approach, env, history[-1]['user'], prompt, overrides, answer, count)
            
                if count + 1 >= instance.retry_count :
                    raise Exception("Step1 OpenAI APIでエラーが発生しました")
                else:
                    time.sleep( instance.retry_interval )
            else:
                # ユーザの質問でキーワードの生成ができなかった場合、ユーザの質問を言い換えるためのフラグを立てる
                if not isChangeQuestion and not "content" in chatCompletion.choices[0].message:
                    isChangeQuestion = True
                    continue
                break
        else:
            raise Exception("Step1 OpenAI APIでエラーが発生しました")

        # 質問を言い換えても検索キーワードが生成できなかった場合は、ユーザの質問とし次の処理に進む
        q = chatCompletion.choices[0].message.content.strip() if  chatCompletion.choices[0].message.content else history[-1]['user']
        q = nonewlines(q)
        
        return q