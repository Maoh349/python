from fileupload.fileuploadprompt import message_type,text_message_type
from config import config_list
from util.getencodingmodel import get_encoding_model

def create_chat_messages(history: list[dict], tenant:str, approach:str, template:str, sources:str, auto_prompt:int|None,chatgpt_deployment, approx_max_tokens) -> list[dict[str, str]]:
    """
    Historyに引数が追加になった場合は都度本メソッドへの影響を確認する

    履歴とソールファイルの文字列を、ChatCompletionの引数の形式に変換する
    例
    history = [ { user:"約款について教えてください" , bot:"約款とは・・・"} , { user:"火災保険は?" } ] 
    sources = "0.@@@文書名:xxx @@@参考リンク:xxx @@@本文:xxx 1.@@@文書名:xxx"
    ↓
    messages = [
        { "role" : "system" , "content" : self.system_prompt} ,
        { "role" : "user" , "content" : "約款について教えてください"} ,
        { "role" : "assistant" , "content" : "約款とは・・・"} ,
        { "role" : "user" , "content" : "火災保険は?" + "###引用情報###" + "0.@@@文書名:xxx @@@参考リンク:xxx @@@本文:xxx 1.@@@文書名:xxx" } 
    ]
    """
    messages = []
    user_message = history[-1]['user']
    #ユーザーの入力文字数が閾値より大きい場合、エラーメッセージを出す
    if len(get_encoding_model(chatgpt_deployment).encode(user_message) )> approx_max_tokens*4:
        raise Exception("プロンプトの文字数を減らしてください")
    
    if isinstance(auto_prompt, int):
        if chatgpt_deployment == config_list[approach]["first_deployment"]: #GPT-3.5の時（文字数制限などあるため場合分けている。GPT-4ominiにアップグレードする際は不要）
            messages = message_type(auto_prompt, user_message, 1)
        elif chatgpt_deployment == config_list[approach]["second_deployment"]:  #GPT-4oの時（GPT-4o以降はこちらのみとなる）
            messages = text_message_type(auto_prompt, user_message)
    else:
        system_prompt = config_list[approach]["system_prompt"]

        messages = [
            { 
                "role":"system",
                "content":system_prompt
            }
        ]
        
        # テンプレート文を追加
        if template and approach in config_list and len(config_list[approach]["prompt_template"]) > int(template):
            select_template = config_list[approach]["prompt_template"][int(template)]
            user_message = select_template.replace("$1", user_message)

        if sources :
            user_message += f"\n###引用情報###\n{sources}"

        messages.append(
            {
                "role":"user",
                "content":user_message,
            }
        )
    
    used_chars = messages[0]["content"]
    used_chars += user_message
    if len( get_encoding_model(chatgpt_deployment).encode(used_chars) ) > approx_max_tokens*4:
        return messages
    history = history[:len(history)-1]
    for chat in reversed(history):
        used_chars += chat['user'] + chat['bot']
        if len( get_encoding_model(chatgpt_deployment).encode(used_chars) ) > approx_max_tokens*4:
            break
        user_chat = {
            "role":"user",
            "content":chat['user']
        }
        messages.insert(1, user_chat)
        assistant_chat = {
            "role":"assistant",
            "content":chat['bot']
        }
        messages.insert(2, assistant_chat)
    
    return messages