import time
from util.logger import create_debug_querylog_error, get_chat_messages_as_text

def getFacets( client, search_index:str, filters:dict, aggs:dict):
    """
    以下のクエリでファセット部分の情報のみ取得する想定
    query_body={ 
        "size": 0,   #ファセット情報のみ表示
         "query": { 
           "bool" : {
             "must" : {
               "match_all": {}  #すべてのデータを検索
             },
             "filter": [   #設定したフィルタ条件で検索範囲を絞りこみ
                 {
                   "terms" : {
                      "filetype.keyword" : ["04001_お申し出回答状（事例集）","04001_お申し出回答状（ひな形・文例集）"]
                   }
                 },
                 {
                    "terms" : {
                      "gyoumu_lv1.keyword" : ["契約関連"]
                   }
                 }
             ]
           }
         },
        "aggs": {  #上記の検索条件を元に検索した対象からファセット情報を生成
            "filetype": {
                "terms": {
                    "field": "filetype.keyword"
                }
            },
            "gyoumu_lv1": { 
                "terms": {
                    "field":"gyoumu_lv1.keyword"
                },
            }
        }
    }
    """
    #検索クエリの土台を定義
    query_body={ 
        "size": 0,
         "query": { 
           "bool" : {
             "must" : {
               "match_all": {}
             },
             "filter": []
           }
         },
        "aggs": aggs
    }

    #フロントで選択したフィルタ条件を設定
    for key in filters:
        if key in aggs:
          terms = {
            "terms":{
              aggs[key]["terms"]["field"] :filters[key] 
            }                           
          }
          query_body["query"]["bool"]["filter"].append(terms)

    retry_count=1000
    for count in range( retry_count ):
        try:
            result = client.search(index=search_index, body=query_body, ignore=400)
            extracted_facets={}
            #レスポンスから各ファセットのリストを抽出
            for key in  result["aggregations"]:
              extracted_facets[key] = result["aggregations"][key]["buckets"]

        except Exception as e:     
            print('retrying...', e)      
            time.sleep(1)        
            if count + 1 >=retry_count :
                raise e    
        else:
            break

    #print (result)
    return extracted_facets

