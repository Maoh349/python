import time
from azure.search.documents.models import QueryType
from util.logger import create_debug_querylog_error
from util.text import nonewlines, stringnewlines
from openai import AzureOpenAI

# ***加藤追記 定義ファイルでインスタンス化して渡したいのでクラス化
# cognitive searchは動作確認してません
class GetRelevantDocumentsCS():

    def handle_search_client_error(self,instance, startTime:str, dt:str, tenant:str, approach:str, env:str, latestQuery:str, q:str, overrides:dict, step1elapsedTime:float):
        """
        エラーログを出力します。
        """
        step2elapsedTime=time.time() - startTime
        params = {
            "answer": "step2 cognitive search apiで例外発生",
            "q":q.replace('\n', '<br>'),
            "search_engine": instance.search_engine,
            "step1elapsedTime":step1elapsedTime,
            "step2elapsedTime":step2elapsedTime
        }
        create_debug_querylog_error(dt, env, latestQuery, overrides, approach, tenant, **params)

    # ***加藤追記 関数名変更しました
    def get_relevant_documents(self,instance, top, overrides: dict, q: str, filters:dict, aggs:dict, fulltext_search_query_body, get_vector_squery_body, tenant:str, approach: str, env: str, latestQuery:str, dt, startTime, step1elapsedTime:float, openai_client: AzureOpenAI) -> list: 
        """
        検索用のキーワードから、関連する文書を取得します。
        """
        use_semantic_captions = True if overrides.get("semantic_captions") else False
        exclude_category = overrides.get("exclude_category") or None
        filter = "category ne '{}'".format(exclude_category.replace("'", "''")) if exclude_category else None
        retry_count=3

        try:
            if overrides.get("semantic_ranker"):
                for count in range(retry_count):
                    try:
                        r = instance.search_client.search(q, 
                            filter=filter,
                            query_type=QueryType.SEMANTIC, 
                            query_language="ja-jp", 
                            query_speller="none", 
                            semantic_configuration_name="default", 
                            top=top, 
                            query_caption="extractive|highlight-false" if use_semantic_captions else None)
                        #正常に取得できたかチェック
                        for i in r:
                            break
                    except Exception as e:     
                        print('retrying...', e)      
                        time.sleep(1)        
                        if count + 1 >=retry_count :
                            raise e    
                    else:
                        break
                
            else:
                for count in range(retry_count):
                    try:
                        r = instance.search_client.search(q, filter=filter, top=top, scoring_statistics="global")
                        #正常に取得できたかチェック
                        for i in r:
                            break
                    except Exception as e:     
                        print('retrying...', e)      
                        time.sleep(1)        
                        if count + 1 >=retry_count :
                            raise e    
                    else:
                        break
        
        except Exception as e:
            self.handle_search_client_error(instance, startTime, dt, tenant, approach, env, latestQuery, q, overrides, step1elapsedTime)
            raise Exception("step2 Cognitive Search APIでエラーが発生しました")
        
        relevant_documents = []
        score = 0
        if use_semantic_captions:
            for doc in r:
                captions_text = nonewlines(" . ".join([c.text for c in doc['@search.captions']]))
                result_str = f"{doc[instance.sourcepage_field]}: {doc[instance.blob_url]}: {captions_text}"
                relevant_documents.append(result_str)
                if i == 2:
                    score = doc["@search.score"]
        else:
            for i, doc in enumerate(r):
                result_str = f"{i+1}. @@@文書名:{doc[instance.sourcepage_field]} @@@参考リンク: {doc[instance.blob_url]} @@@本文: {stringnewlines(doc[instance.content_field])}\n\n\n"
                relevant_documents.append(result_str)
                if i == 2:
                    score = doc["@search.score"]
        
        return relevant_documents, score
