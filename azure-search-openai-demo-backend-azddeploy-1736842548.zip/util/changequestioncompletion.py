
system_question_prompt = """
    あなたは検索しようとしているユーザを補助するシステムです。
    ユーザの会話や質問に基づいて質問文を検索クエリに変換します。
    質問の意味を変えずに言い回しを変えてください
    
    ###条件###
    ・出力は検索クエリのみとしてください。
    ・検索クエリ以外の返信は不要です。

    ###例###
    入力：転換契約
    出力：転換契約について教えてください

    入力：保険の契約書をなくした場合の対応はどうしたらいいですか?
    出力：保険の契約書紛失時の対応方法は何ですか？
    """

def create_chat_question_messages(question):
    """
    ユーザの質問を言い変えるmessageを作成
    messages = [
        { "role" : "system" , "content" : "あなたは検索しようと～"} ,
        { "role" : "user" , "content" : "入力： 約款について\n出力："} 
    ]
    """
    messages = [
        { 
            "role":"system",
            "content":system_question_prompt
        },
        {
            "role":"user",
            "content": f"入力：{question}\n出力：" #システムプロンプトのFew Shotに準ずる形にする
        }
    ]
    
    return messages

def create_chat_question(question, gpt_deployment, openai_client):
    """
    ユーザからの質問でキーワードの生成ができなかった場合のみ使用
    OpenAIにユーザの質問を別の言い回しに変換する
    """
    messages = create_chat_question_messages(question)
    questionCompletion = openai_client.chat.completions.create(
        model=gpt_deployment,
        messages = messages,
        temperature=0, 
        max_tokens=100, 
        n=1, 
        stop=None,
        timeout=60)
    
    return questionCompletion