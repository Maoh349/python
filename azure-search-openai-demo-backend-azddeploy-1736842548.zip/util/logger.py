import datetime
import json
import os
import socket
import threading
import traceback

LOG_SPLIT_CHARAS = int(os.environ.get("LOG_SPLIT_CHARAS") or "4500")

def get_chat_messages_as_text(messages, approx_max_tokens) -> str:
    """
    ログに出力するためにChatCompletionの引数の形式(JSON型)を文字列にする
    """
    massages_text_list = []
    messages_text = ""
    for message in messages:
        massages_text_list.append( json.dumps (message) )
        messages_text = " ".join(massages_text_list).encode().decode('unicode-escape')
        if len( messages_text ) > approx_max_tokens*4:
            break

    return messages_text 

def output_log(log_params, log_name:str, target:str):
    """
    ログを出力します。
    """
    # ログが切れないようにtarget(prompt,history)を分割して出力する
    if target in log_params[log_name] and len(str(log_params[log_name][target])) > LOG_SPLIT_CHARAS:
        target_str = str(log_params[log_name][target])
        split_prompt = [target_str[i:i+LOG_SPLIT_CHARAS] for i in range(0, len(target_str), LOG_SPLIT_CHARAS)]
        for i, sub_prompt in enumerate(split_prompt):
            sub_debug_querylog = log_params.copy()
            sub_debug_querylog[log_name][target] = sub_prompt
            sub_debug_querylog[log_name]["split_no"] = i + 1
            print( json.dumps(log_params, ensure_ascii=False), flush=True )
    else:
        print( json.dumps(log_params, ensure_ascii=False), flush=True )

def create_debug_querylog_info(dt, env, latestQuery, overrides, approach, tenant, **kwargs):
    """
    debug_querylogのInfoログを出力します。
    """
    
    debug_querylog = {
        "debug_querylog": {
            "starttime": dt,
            "type": "info", # info or error
            "env": env, # honban or advance
            "query": latestQuery,
            "template":overrides.get("prompt_template") or "",
            "hostname": socket.gethostname(),
            "processid": os.getpid(),
            "threadid": threading.get_ident(),
            "username": overrides.get("user_name"),
            "userid": overrides.get("user_id"),
            "userjobtitle": overrides.get("user_jobtitle"),
            "userdepartment": overrides.get("user_department"),
            "approach": approach,
            "tenant": tenant,
            **kwargs
        }
    }

    output_log(debug_querylog, "debug_querylog", "prompt")

def create_debug_querylog_error(dt, env, latestQuery, overrides, approach, tenant, **kwargs):
    """
    debug_querylogのerrorログを出力します。
    """
    
    debug_querylog = {
        "debug_querylog": {
            "starttime": dt,
            "type": "error", # info or error
            "env": env, # honban or advance
            "query": latestQuery,
            "template":overrides.get("prompt_template") or "",
            "exception" : traceback.format_exc().replace('\n', '<br>'),
            "hostname": socket.gethostname(),
            "processid": os.getpid(),
            "threadid": threading.get_ident(),
            "username": overrides.get("user_name"),
            "userid": overrides.get("user_id"),
            "userjobtitle": overrides.get("user_jobtitle"),
            "userdepartment": overrides.get("user_department"),
            "approach": approach,
            "tenant": tenant,
            **kwargs
        }
    }

    output_log(debug_querylog, "debug_querylog", "prompt")

def create_debug_conversationlog_info(env:str, action:str, conversation):
    dt = datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S") 
    debug_conversationlog={
        "debug_conversationlog":{
            "starttime": dt,
            "type": "info",
            "action": action,
            "env": env,
            "tenant": conversation["tenant"],
            "userid": conversation["userid"]
        }
    }
    if action == "delete" or action == "upload":
        # "yyyy/mm/dd HH:MM:ss" → "yyyymmdd_HHMMss"形式の文字列に変換
        formatted_datetime = conversation["conversation_timestamp"].replace('/', '').replace(' ', '_').replace(':', '')
        # Blobから削除したファイル名
        filename = f"conversation_{formatted_datetime}"
        debug_conversationlog["debug_conversationlog"]["filename"] = filename
    
    print( json.dumps(debug_conversationlog, ensure_ascii=False),flush=True)

def create_debug_conversationlog_error(env:str, action:str, conversation, message):
    dt = datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S") 
    debug_conversationlog={
        "debug_conversationlog":{
            "starttime": dt,
            "type": "error",
            "action": action,
            "env": env,
            "tenant": conversation["tenant"],
            "userid": conversation["userid"],
            "message": message
        }
    }
    if action == "delete" or action == "update":
        # "yyyy/mm/dd HH:MM:ss" → "yyyymmdd_HHMMss"形式の文字列に変換
        formatted_datetime = conversation["conversation_timestamp"].replace('/', '').replace(' ', '_').replace(':', '')
        # Blobから削除したファイル名
        filename = f"conversation_{formatted_datetime}"
        debug_conversationlog["debug_conversationlog"]["filename"] = filename
    
    print( json.dumps(debug_conversationlog, ensure_ascii=False),flush=True)

def create_debug_esg_azure_log_error(env:str, action:str, overrides:dict, **kwargs):
    debug_esg_azure_log = {
        "debug_esg_azure_log" : {
            "env" : env,
            "action" : action,
            "username": overrides.get("user_name"),
            "userid": overrides.get("user_id"),
            "userjobtitle": overrides.get("user_jobtitle"),
            "userdepartment": overrides.get("user_department"),
            "hostname": socket.gethostname(),
            "processid": os.getpid(),
            "threadid": threading.get_ident(),
            "approach" : "esg-search",
            **kwargs
        }
    }

    print(json.dumps(debug_esg_azure_log, ensure_ascii=False), flush=True)
    
def get_chat_fileUpload_messages_as_text(messages, answer) -> str:
    """
    ログに出力するためにChatCompletionの引数の形式(JSON型)を文字列にする
    """
    massages_text_list = []
    messages_text = ""
    for message in messages:
        massages_text_list.append( json.dumps (message) )
        messages_text = " ".join(massages_text_list).encode().decode('unicode-escape')
    fileupload_result = messages_text+"<Punctuation>"+answer
    return fileupload_result

def handle_autoPrompt_success_log(dt:str, env:str, latestQuery:str, overrides:dict, q:str, prompt:str, approach:str,temparature:int, tenant:str, **kwargs):
    """
    infoログを出力します。
    """
    params = {
        "search": q.replace('\n', '<br>'),
        "prompt": prompt.replace('\n', '<br>'),
        "engine": kwargs['model_name'] if 'model_name' in kwargs  else None,
        "temparature": temparature,
        "3rd_score": "",
        "search_engine": "",
        "step1elapsedTime": "",
        "step2elapsedTime": "",
        "step3elapsedTime": "",
        "auto_prompt": kwargs['auto_prompt'] if 'auto_prompt' in kwargs  else None,
        **kwargs
    }
    create_debug_querylog_info(dt, env, latestQuery, overrides, approach, tenant, **params)

def handle_image_autoPrompt_success_log(dt:str, env:str, latestQuery:str, overrides:dict, q:str, fileNames:list, prompt:str, answer:str, approach:str,temparature:int, tenant:str, **kwargs):
    """
    infoログを出力します。
    """
    params = {
        "search": q.replace('\n', '<br>'),
        "filename":fileNames,
        "prompt": prompt,
        "answer":answer,
        "engine": kwargs['model_name'] if 'model_name' in kwargs  else None,
        "temparature": temparature,
        "3rd_score": "",
        "search_engine": "",
        "step1elapsedTime": "",
        "step2elapsedTime": "",
        "step3elapsedTime": "",
        "auto_prompt": kwargs['auto_prompt'] if 'auto_prompt' in kwargs  else None,
        **kwargs
    }
    create_debug_querylog_info(dt, env, latestQuery, overrides, approach, tenant, **params)

def handle_image_userPrompt_success_log(dt:str, env:str, latestQuery:str, overrides:dict, q:str, fileNames:list, prompt:str, answer:str, approach:str,temparature:int, tenant:str, **kwargs):
    """
    infoログを出力します。
    """
    params = {
        "search": q.replace('\n', '<br>'),
        "filename":fileNames,
        "prompt": prompt,
        "answer":answer,
        "engine": kwargs['model_name'] if 'model_name' in kwargs  else None,
        "temparature": temparature,
        "3rd_score": "",
        "search_engine": "",
        "step1elapsedTime": "",
        "step2elapsedTime": "",
        "step3elapsedTime": "",
        "auto_prompt": kwargs['auto_prompt'] if 'auto_prompt' in kwargs  else None,
        **kwargs
    }
    create_debug_querylog_info(dt, env, latestQuery, overrides, approach, tenant, **params)