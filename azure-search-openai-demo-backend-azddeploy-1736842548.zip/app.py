import os
import mimetypes
import time
import logging
import urllib.parse
import json
import datetime
import io
import threading
import pandas as pd
import uuid
from openai import AzureOpenAI
from flask import Flask, request, jsonify,Response
from azure.identity import DefaultAzureCredential
from azure.search.documents import SearchClient
from elasticsearch import Elasticsearch
from conversations.updataconversation import uploadConversationBlob
from conversations.deleteconversation import deleteConversationBlob, deletePastConversationBlob
from conversations.getconversation import retrieveUserConversation
from azure.storage.blob import BlobServiceClient
from util.logger import output_log
from util.feedbackrecord import likeFeedbackUpdate
from util.feedbackrecord import dislikeFeedbackUpdate
from util.feedbackrecord import clickCountUpdate
from util.getFacets import getFacets
from util.logger import create_debug_conversationlog_info, output_log
from config import api_config_list, config_list
from approaches.readprepretrievellm import ReadPrepRetrieveLLM
from fileupload import uploadprocess
from fileupload.fileuploadchat import fileUploadChat
from esg_src.util.azureutils import GetTmpFileInfo, Deleteoutput, DeleteTmpFile, UploadESGFile, UpdateTmpFile, ChangeStatusTmpFile
from esg_src.controller.controller import ESGController
from esg_src.esg_config import esg_config_list

#added by Shigeki for local build
mimetypes.add_type('application/javascript', '.js')
mimetypes.add_type('text/css', '.css')

APP_ENVIRONMENT = os.environ.get("APP_ENVIRONMENT") or "honban"
AZURE_OPENAI_SERVICE = os.environ.get("AZURE_OPENAI_SERVICE") or "myopenai_us"
AZURE_STORAGE_ACCOUNT = os.environ.get("AZURE_STORAGE_ACCOUNT") or "mystorageaccount"
AZURE_STORAGE_CONTAINER = os.environ.get("AZURE_STORAGE_CONTAINER") or "content"
AZURE_STORAGE_CONVERSATION = os.environ.get("AZURE_STORAGE_CONVERSATION") or "conversation"
STOCKED_CONVERSATION_NUM = int(os.environ.get("STOCKED_CONVERSATION_NUM") or "5")
AZURE_WEB_URL = os.environ.get("AZURE_WEB_URL") or "https://app-backend-aiassistant-st.azurewebsites.net/"
ALLOW_CHUNK_MAX_LENGTH = int(os.environ.get("ALLOW_CHUNK_MAX_LENGTH") or "80000")
ALLOW_CHUNK_HEAD_LENGTH = int(os.environ.get("ALLOW_CHUNK_HEAD_LENGTH") or "200")
GPT35_ALLOW_CHUNK_MAX_LENGTH = int(os.environ.get("GPT35_ALLOW_CHUNK_MAX_LENGTH") or "10000")
GPT35_ALLOW_CHUNK_HEAD_LENGTH = int(os.environ.get("GPT35_ALLOW_CHUNK_HEAD_LENGTH") or "200")
AZURE_OPENAI_FIRST_DEPLOYMENT = os.environ.get("AZURE_OPENAI_FIRST_DEPLOYMENT") or "GPT16K"
AZURE_OPENAI_SECOND_DEPLOYMENT = os.environ.get("AZURE_OPENAI_SECOND_DEPLOYMENT") or "GPT-4o"
AZURE_OPENAI_API_VERSION = os.environ.get("AZURE_OPENAI_API_VERSION") or "2024-02-01"
MODEL_DICT = {"first_deployment": AZURE_OPENAI_FIRST_DEPLOYMENT,"second_deployment": AZURE_OPENAI_SECOND_DEPLOYMENT,}


# Use the current user identity to authenticate with Azure OpenAI, Cognitive Search and Blob Storage (no secrets needed, 
# just use 'az login' locally, and managed identity when deployed on Azure). If you need to use keys, use separate AzureKeyCredential instances with the 
# keys for each service
# If you encounter a blocking error during a DefaultAzureCredntial resolution, you can exclude the problematic credential by using a parameter (ex. exclude_shared_token_cache_credential=True)
azure_credential = DefaultAzureCredential()
openai_token = azure_credential.get_token("https://cognitiveservices.azure.com/.default")
api_key = openai_token.token
openai_client = AzureOpenAI(
    api_key=api_key,  
    api_version=AZURE_OPENAI_API_VERSION,
    base_url=f"https://{AZURE_OPENAI_SERVICE}.openai.azure.com/openai/",
)

# Set up clients for Cognitive Search and Storage
blob_client = BlobServiceClient(
    account_url=f"https://{AZURE_STORAGE_ACCOUNT}.blob.core.windows.net", 
    credential=azure_credential)
blob_container = blob_client.get_container_client(AZURE_STORAGE_CONTAINER)
blob_conversation_container = blob_client.get_container_client(AZURE_STORAGE_CONVERSATION)
# Various approaches to integrate GPT and external knowledge, most applications will use a single one of these patterns
# or some derivative, here we include several for exploration purposes

app = Flask(__name__)

@app.route("/", defaults={"path": "index.html"})
@app.route("/<path:path>")
def static_file(path):
    return app.send_static_file(path)

# Serve content files from blob storage from within the app to keep the example self-contained. 
# *** NOTE *** this assumes that the content files are public, or at least that all users of the app
# can access all the files. This is also slow and memory hungry.
@app.route("/content/<path:path>")
def content_file(path):
    filename = urllib.parse.unquote(path)
    blob = blob_container.get_blob_client(path).download_blob()
    mime_type = blob.properties["content_settings"]["content_type"]
    if mime_type == "application/octet-stream":
        mime_type = mimetypes.guess_type(filename)[0] or "application/octet-stream"

    #　filenameは実際はpath, ダウンロードされるファイル名はfilenameになるので、path -> 実際のファイル名になるように処理 
    if ".csv" in filename:
        filename = filename.split("/")[-1]

    return blob.readall(), 200, {"Content-Type": mime_type, "Content-Disposition": f"inline; filename*=UTF-8''{urllib.parse.quote(filename.encode('utf-8'))}"}

def answer():
    ensure_openai_token()
    approach = request.json["approach"]
    data_points = request.json["data_points"] if "data_points" in request.json else False
    filters = request.json["filters"] if "filters" in request.json else {}
    aggs = request.json["aggs"] if "aggs" in request.json else {}
    model_name = MODEL_DICT.get(request.json["openai_model"]) if "openai_model" in request.json else AZURE_OPENAI_FIRST_DEPLOYMENT

    endpoint = request.url_rule.rule[1:]
    try:
        # 回答毎にインスタンス作成しないように、シングルトンでインスタンスを取得するように修正
        impl = ReadPrepRetrieveLLM(model_name, config_list, api_config_list, endpoint, approach)
        if not impl:
            return jsonify({"error": "unknown approach"}), 400
        r = impl.run(request.json["history"], data_points,filters, aggs,request.json.get("overrides") or {}, request.json["tenant"], approach, APP_ENVIRONMENT, openai_client)
        citationList = request.json["list_data_points"]
        
        #書状wf（選択されたcitationに対してlike_count+1）
        if request.json["feedbackUpdateTriger"]["like"]["timing"] == "send":
            search_index = config_list[approach]["search_index"]

            #選択されたcitationに対してlike_count+1をする
            likeFeedbackUpdate(config_list[approach]["search_client"],citationList,search_index)

        return Response(r, mimetype='text/event-stream')
    except Exception as e:
        logging.exception("Exception in askData")
        return jsonify({"error": str(e)}), 500
    
## エンドポイントの追加
for apiname, config in api_config_list.items():
    app.add_url_rule("/"+apiname,"answer",answer,methods=["POST"])


@app.route("/feedback", methods=["POST"])
def feedback():
    try:
        index = request.json["index"]
        tenant = request.json["tenant"]
        approach = request.json["approach"]
        feedback = request.json["feedback"]
        history = request.json["history"]
        citationIndex = request.json.get("citationIndex",  "")
        clickedCitation = request.json.get("clickedCitation",  "")
        message = request.json["message"]
        userName = request.json.get("user_name",  "")
        jobTitle = request.json.get("user_jobtitle",  "")
        department = request.json.get("user_department",  "")
        userId = request.json.get("user_id",  "")

        dt = datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S") 

        # dislikeの評価を登録する
        if feedback == "dislike" and request.json["feedbackUpdateTriger"]["dislike"]["timing"] == "click":
            # 登録すべきFBを選択していた場合、citationすべてにdislike_count+1をする
            checkbox = message.get("checkbox")
            if bool(set(request.json["feedbackUpdateTriger"]["dislike"]["word"]) & set(checkbox)):
                search_client = config_list[approach]["search_client"]
                search_index = config_list[approach]["search_index"]
                list_citation = history[index][1]["sourcepages"]

                dislikeFeedbackUpdate(search_client, list_citation, search_index)

        # likeの評価を登録する
        if feedback == "like" and request.json["feedbackUpdateTriger"]["like"]["timing"] == "click":
            search_client = config_list[approach]["search_client"]
            list_citation = history[index][1]["sourcepages"]
            search_index = config_list[approach]["search_index"]
            likeFeedbackUpdate(search_client ,list_citation, search_index)

        debug_feedbacklog={
            "debug_feedbacklog":{
                "starttime":dt,
                "type":"info",
                "index":index,
                "env":APP_ENVIRONMENT,  
                "tenant":tenant,              
                "approach":approach,
                "feedback":feedback,
                "history":history,
                "citationIndex":citationIndex,
                "clickedCitation":clickedCitation,
                "message":message,
                "username": userName,
                "userjobtitle": jobTitle,
                "userdepartment": department,
                "userid": userId
            }
        }
        output_log(debug_feedbacklog, "debug_feedbacklog", "history")

        return jsonify({"message": "done" }), 200

    except Exception as e:
        logging.exception("Exception in /feedback")
        return jsonify({"error": str(e)}), 500

@app.route("/citationClick", methods=["POST"])
def citationClick():
    try:
        tenant = request.json["tenant"]
        approach = request.json["approach"]
        question = request.json["question"]
        citationIndex = request.json["citationIndex"]
        clickedCitation = request.json["clickedCitation"]
        userName = request.json.get("user_name",  "")
        jobTitle = request.json.get("user_jobtitle",  "")
        department = request.json.get("user_department",  "")
        userId = request.json.get("user_id",  "")
         
        dt = datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S") 
        
        # 参考文書のクリック数を更新する
        if request.json["isRegisterClickCounts"]:
            search_client = config_list[approach]["search_client"]
            search_index = config_list[approach]["search_index"]
            # click_count+1をする
            clickCountUpdate(search_client, clickedCitation, search_index)
        
        debug_citationclicklog={
            "debug_citationclicklog":{
                "starttime":dt,
                "type":"info",
                "env":APP_ENVIRONMENT,
                "tenant":tenant,              
                "approach":approach,
                "question":question,
                "citationIndex":citationIndex,
                "clickedCitation":clickedCitation,
                "username": userName,
                "userjobtitle": jobTitle,
                "userdepartment": department,
                "userid": userId
            }
        }
        print( json.dumps(debug_citationclicklog, ensure_ascii=False),flush=True)

        return jsonify({"message": "done" }), 200

    except Exception as e:
        logging.exception("Exception in /citationClick")
        return jsonify({"error": str(e)}), 500

@app.route("/fetchFacets", methods=["POST"])
def fetchFacets():
    try:
        approach = request.json["approach"]
        query = request.json["query"]
        filters = request.json["filters"]
        aggs =  request.json["aggs"]
        search_client = config_list[approach]["search_client"]
        search_index = config_list[approach]["search_index"]        
        result= getFacets( search_client, search_index, filters, aggs)

        return jsonify({"filters": result})

    except Exception as e:
        logging.exception("Exception in /fetchFacets")
        return jsonify({"error": str(e)}), 500

@app.route("/deleteConversation", methods=["POST"])
def deleteConversation():
    try:
        r = deleteConversationBlob(blob_conversation_container, APP_ENVIRONMENT, request.json["conversation"])
        return jsonify(r), 200

    except Exception as e:
        logging.exception("Exception in /deleteConversation")
        return jsonify({"error": str(e)}), 500

@app.route("/getConversation", methods=["POST"])
def getConversation():
    try:
        r = retrieveUserConversation(blob_conversation_container, request.json["userid"], request.json["tenant"], APP_ENVIRONMENT)
        create_debug_conversationlog_info(APP_ENVIRONMENT, "get", {"userid":request.json["userid"], "tenant":request.json["tenant"]})
        result = deletePastConversationBlob(blob_conversation_container, r, APP_ENVIRONMENT, STOCKED_CONVERSATION_NUM)
        result["stockedConversation"] = STOCKED_CONVERSATION_NUM

        return jsonify(result)

    except Exception as e:
        logging.exception("Exception in /getConversation")
        return jsonify({"error": str(e)}), 500
    
@app.route("/uploadConversation", methods=["POST"])
def uploadConversation():
    try:
        r = uploadConversationBlob(blob_conversation_container, request.json["conversation"], APP_ENVIRONMENT)
        return jsonify({"conversation": r}), 200

    except Exception as e:
        logging.exception("Exception in /uploadConversation")
        return jsonify({"error": str(e)}), 500
    
@app.route("/debuglog", methods=["POST"])
def debugLog():
    try:
        content = request.json["content"]
         
        dt = datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S") 
       
        debug_log={
            "debug_log":{
                "starttime":dt,
                "type":"info",
                "env":APP_ENVIRONMENT,
                "content":content,
            }
        }
        print( json.dumps(debug_log, ensure_ascii=False), flush=True )

        return jsonify({"message": "done" }), 200

    except Exception as e:
        logging.exception("Exception in /debuglog")
        return jsonify({"error": str(e)}), 500

###以下ESGのAPI
# ファイルアップロードして、実行待ちの時のAPI
@app.route("/answerESG", methods=["POST"])
def esg():
    ensure_openai_token()
    try :
        jsonData = json.loads(request.form["jsonData"])
        file = request.files["file"]
        # jsondataの取得
        overrides = jsonData["overrides"]
        tenant = jsonData["tenant"]
        approach = jsonData["approach"]
        model_name = MODEL_DICT.get(jsonData["openai_model"]) if "openai_model" in jsonData else AZURE_OPENAI_FIRST_DEPLOYMENT
    except Exception as e:
        return jsonify({"error" : {"message" : str(e), "tip" : "invalid request parameters"}}), 400
    
    #スレッドごとに一意のキーを作成・このキーをスレッドの目印として使用
    thread_key = str(uuid.uuid4())+"$esg$"

    # 一度読み込むとファイルを読み込めなくなるので、メモリ上にファイルを保存する
    file_stream = io.BytesIO(file.read())

    # csvファイルのデータの取得
    try:
        try:
            file_stream.seek(0)
            df = pd.read_csv(file_stream, encoding='utf-8')
        except UnicodeDecodeError:
            try:
                file_stream.seek(0)
                df = pd.read_csv(file_stream, encoding="shift-jis")
            except UnicodeDecodeError:
                file_stream.seek(0)
                df = pd.read_csv(file_stream, encoding="cp932")
    
        df = df.fillna("")
        input_filename = file.filename
        file_stream.close()
    except Exception as e:
        file_stream.close()
        return jsonify({"error" : {"message" : str(e), "tip" : "invalid filetype"}}), 500

    # 最初にアクセスしたときにtmp_file、初期CSVを作成
    try:
        #ファイル名作成/日本時間に合わせる
        now = datetime.datetime.now()+datetime.timedelta(hours=9)
        # "yyyymmdd_HHMMss"形式の文字列に変換
        created = now.strftime('%Y/%m/%d %H:%M')
        formatted_datetime = now.strftime("%Y%m%d_%H%M%S")
        
        output_filename = "出力結果_"+input_filename[:-4]+"_"+formatted_datetime+".csv"
        tmp_df = pd.DataFrame(["エラーにより中断しました。入力データに適切なデータがあるかどうか確認してください。"])
        total_num_of_scheduled_tasks = len(df)
        UpdateTmpFile(blob_container, overrides, input_filename, output_filename, thread_key, total_num_of_scheduled_tasks, 0, "initialization", created)
        UploadESGFile(blob_container, tmp_df, thread_key, output_filename, overrides)
        
    except Exception as e:
        logging.exception("Exception in /answerESG")
        return jsonify({"error" : {"message" : str(e), "tip" : "failed to create tmpfile"}}), 500
    
    if model_name == AZURE_OPENAI_FIRST_DEPLOYMENT:
        initial_values = {
            "search_client": esg_config_list[approach]["search_client"],
            "search_index": esg_config_list[approach]["search_index"],
            "storage": esg_config_list[approach]["storage"],
            "sourcepage_field": esg_config_list[approach]["sourcepage_field"],
            "blob_url": esg_config_list[approach]["blob_url"],
            "content_field": esg_config_list[approach]["content_field"],            
            "further_question_score": esg_config_list[approach]["further_question_score"],
            "search_engine": esg_config_list[approach]["search_engine"],
            "fields": esg_config_list[approach]["fields"],
            "chatgpt_deployment": esg_config_list[approach]["first_deployment"],
            "embedding_deployment": esg_config_list[approach]["embedding_deployment"],
            "retry_count": esg_config_list[approach]["retry_count"],
            "retry_interval": esg_config_list[approach]["retry_interval"],
            "chat_temperature": esg_config_list[approach]["chat_temperature"],
            "system_prompt": esg_config_list[approach]["system_prompt"],
            "prompt_template": esg_config_list[approach]["prompt_template"],
            "output_max_token": esg_config_list[approach]["output_max_token"],
            "max_thread_num": esg_config_list[approach]["max_thread_num"], 
            "thread_sleep_time": esg_config_list[approach]["thread_sleep_time"],
            "blob_container": blob_container,
            "approx_max_tokens": esg_config_list[approach]["first_model_approx_max_tokens"],
            "token_threshold": esg_config_list[approach]["token_threshold"],
        }
    elif model_name == AZURE_OPENAI_SECOND_DEPLOYMENT:
        initial_values = {
            "search_client": esg_config_list[approach]["search_client"],
            "search_index": esg_config_list[approach]["search_index"],
            "storage": esg_config_list[approach]["storage"],
            "sourcepage_field": esg_config_list[approach]["sourcepage_field"],
            "blob_url": esg_config_list[approach]["blob_url"],
            "content_field": esg_config_list[approach]["content_field"],            
            "further_question_score": esg_config_list[approach]["further_question_score"],
            "search_engine": esg_config_list[approach]["search_engine"],
            "fields": esg_config_list[approach]["fields"],
            "chatgpt_deployment": esg_config_list[approach]["second_deployment"],
            "embedding_deployment": esg_config_list[approach]["embedding_deployment"],
            "retry_count": esg_config_list[approach]["retry_count"],
            "retry_interval": esg_config_list[approach]["retry_interval"],
            "chat_temperature": esg_config_list[approach]["chat_temperature"],
            "system_prompt": esg_config_list[approach]["system_prompt"],
            "prompt_template": esg_config_list[approach]["prompt_template"],
            "output_max_token": esg_config_list[approach]["output_max_token"],
            "max_thread_num": esg_config_list[approach]["max_thread_num"], 
            "thread_sleep_time": esg_config_list[approach]["thread_sleep_time"],
            "blob_container": blob_container,
            "approx_max_tokens": esg_config_list[approach]["second_model_approx_max_tokens"],
            "token_threshold": esg_config_list[approach]["token_threshold"],
        }

    target = ESGController(**initial_values)

    # スレッド使うと、try/exceptでエラー拾ってくれない
    thread = threading.Thread (target=target.Controller, args=(overrides, input_filename,output_filename, df, thread_key, total_num_of_scheduled_tasks,tenant , APP_ENVIRONMENT , approach, created, AZURE_WEB_URL, openai_client), name = thread_key)
    thread.start()
    
    return jsonify({"message" : "process start"})

# tmpファイルのstatus一覧を取得するAPI
@app.route("/checkStatusESG", methods=["POST"])
def checkeStatus():
    try:
        overrides = request.json["overrides"]
    except Exception as e:
        logging.exception("Exception in /check_status_esg")
        return jsonify({"error" : {"message" : str(e), "tip" : "invalid request parameters"}}), 400

    # 存在するtmpファイルの情報を返す関数
    # 存在しないときは[]空が返ってくる
    try:
        thread_key_list = GetTmpFileInfo(blob_container,  AZURE_STORAGE_CONTAINER, AZURE_WEB_URL, overrides)
        return jsonify({"thread_key_list" : thread_key_list}) , 200
    except Exception as e:
        logging.exception("Exception in /check_status_esg")
        return jsonify({"error" : {"message" : str(e), "tip" :"failed to get tmpfile" }}), 500

# tmpfile
@app.route("/cancelESG", methods=["POST"])
def cancel():
    try:
        overrides = request.json["overrides"]
        thread_key = request.json["thread_key"]
    except Exception as e:
        logging.exception("Exception in /get_url")
        return jsonify({"error" : {"message" : str(e), "tip" : "invalid request parameters"}}), 400
    
    try:
        ChangeStatusTmpFile(blob_container, overrides, thread_key)
        return jsonify({"message" : "success"}), 200
    except Exception as e:
        logging.exception("Exception in /deleteFileESG")
        return jsonify({"error" : {"message" : str(e), "tip" :"中断でエラーが発生しました" }}), 500

# esg関連のファイルを削除するときのAPI
@app.route("/deleteFileESG", methods = ["POST"])
def delete_tmpfile():
    try:
        overrides = request.json["overrides"]
        output_filename = request.json["output_filename"]
        thread_key = request.json["thread_key"]
    except Exception as e:
        logging.exception("Exception in /deleteFileESG")
        return jsonify({"error" : {"message" : str(e), "tip" : "invalid request parameters"}}), 400

    try:
        DeleteTmpFile(blob_container, thread_key, overrides)
        Deleteoutput(blob_container, output_filename, overrides)
        return jsonify({"message" : "success"}), 200
    except Exception as e:
        logging.exception("Exception in /deleteFileESG")
        return jsonify({"error" : {"message" : str(e), "tip" :"fileの削除でエラーが発生しました" }}), 500

    
@app.route("/fileUpload", methods=["POST"])
def fileupload():
    try:
        dt = datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S") 
        jsonData = json.loads(request.form["jsonData"])
        # ファイルの有無、ファイル形式の確認
        if 'files' not in request.files:
            return 'No file part', 400
            
        files = request.files.getlist('files')        
        # model_name =  MODEL_DICT.get(jsonData["openai_model"]) if "openai_model" in jsonData else AZURE_OPENAI_FIRST_DEPLOYMENT
        model_name =  MODEL_DICT.get(jsonData["openai_model"]) if "openai_model" in jsonData else AZURE_OPENAI_FIRST_DEPLOYMENT

        if model_name == AZURE_OPENAI_FIRST_DEPLOYMENT:
            results = uploadprocess.get_file_chunk_info(dt,jsonData,files,APP_ENVIRONMENT)
        elif model_name == AZURE_OPENAI_SECOND_DEPLOYMENT:
            results = uploadprocess.get_file_image_info(dt,jsonData,files,APP_ENVIRONMENT)

        return jsonify(results)
    except Exception as e:
        logging.exception("Exception in /fileUpload")
        return jsonify({"error": str(e)}), 500


@app.route("/answerWithGenerateArticle", methods=["POST"])
def answerWithGenerateArticle():
    ensure_openai_token()
    try:
        approach = request.json["approach"]
        history=request.json["history"]
        tenant=request.json["tenant"]
        overrides=request.json["overrides"]
        if "fileNames" in request.json: #GPT-4oの時
            fileNames = request.json["fileNames"]
        else:   #GPT-3.5の時
            fileNames = []
        if "chunk" in request.json: #GPT-3.5の時
            chunk = request.json["chunk"]
        else:   #GPT-4oの時
            chunk = []
        if "base64Images" in request.json:  #GPT-4oの時
            base64Images = request.json["base64Images"]
        else:   #GPT-3.5の時
            base64Images = []
        model_name = MODEL_DICT.get(request.json["openai_model"]) if "openai_model" in request.json else AZURE_OPENAI_FIRST_DEPLOYMENT
        chat_instance = fileUploadChat(model_name, openai_client, approach, fileNames, chunk, base64Images, history, tenant, overrides, APP_ENVIRONMENT)
        if not base64Images:  #GPT-3.5の時
            if "autoPromptMode" in list(overrides):
                auto_prompt=overrides["autoPromptMode"]
                if(auto_prompt in [1]):
                    mix_answer = chat_instance.mix_process(auto_prompt)
                    return mix_answer
                elif(auto_prompt in [0,2,3,4]):
                    join_answer = chat_instance.join_process(auto_prompt)
                    return join_answer
            else:
                template_answer=chat_instance.template_process()
                return  template_answer
        else:    #GPT-4oの時
            if "autoPromptMode" in list(overrides):
                auto_prompt=overrides["autoPromptMode"]
                answer = chat_instance.answer_by_autoprompt(auto_prompt)
            else:
                answer = chat_instance.answer_by_userprompt()
            
            return Response(answer, mimetype='text/event-stream')


    except Exception as e:
        logging.exception("Exception in /answerWithGenerateArticle")
        return jsonify({"error": str(e)}), 500


def ensure_openai_token():
    global openai_token
    global openai_client
    if openai_token.expires_on < int(time.time()) - 60:
        openai_token = azure_credential.get_token("https://cognitiveservices.azure.com/.default")
        api_key = openai_token.token
        openai_client = AzureOpenAI(
            api_key=api_key,  
            api_version=AZURE_OPENAI_API_VERSION,
            base_url=f"https://{AZURE_OPENAI_SERVICE}.openai.azure.com/openai/",
        )
if __name__ == "__main__":
    app.run(threaded=True) 
